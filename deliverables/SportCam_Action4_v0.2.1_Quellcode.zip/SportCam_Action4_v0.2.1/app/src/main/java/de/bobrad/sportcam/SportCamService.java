package de.bobrad.sportcam;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.provider.Settings;
import android.util.AtomicFile;
import android.util.Base64;
import de.bobrad.sportcam.core.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

public final class SportCamService extends Service implements DjiBleCamera.Listener {
    public final class LocalBinder extends Binder { public SportCamService get(){return SportCamService.this;} }
    private final LocalBinder binder=new LocalBinder();
    public final MatchClock clock=new MatchClock();
    public final EventLedger remote=new EventLedger();
    public final Map<String,DjiBleCamera> cameras=new LinkedHashMap<>();
    public final LinkedHashMap<String,BluetoothDevice> found=new LinkedHashMap<>();
    public final ArrayList<String> logLines=new ArrayList<>();
    public String selected="LEFT",matchId="",matchTitle="Neues Spiel",syncStatus="Supporter-Schnittstelle noch nicht angebunden";
    public boolean scanning=false,syncing=false,archiving=false;
    public Runnable uiListener;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private JSONArray markers=new JSONArray(),clockEvents=new JSONArray(),observations=new JSONArray();
    private final Map<String,Boolean> observedRecording=new HashMap<>();
    private String cursor="";
    private boolean foreground=false,destroyed=false,storageWritable=true;
    private AtomicFile store;
    private long lastCheckpoint=0;
    private BluetoothLeScanner scanner;
    @Override public void onCreate(){
        super.onCreate();store=new AtomicFile(new File(getFilesDir(),"match-state.json"));
        byte[] identity=identity();
        for(String side:new String[]{"LEFT","RIGHT"})cameras.put(side,new DjiBleCamera(this,side,identity,this));
        restore();
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("camera","SportCam Kameraverbindung",NotificationManager.IMPORTANCE_LOW));
        main.post(tick);
    }
    private byte[] identity(){
        SharedPreferences p=getSharedPreferences("camera",0);String saved=p.getString("identity","");
        if(!saved.isEmpty())try{byte[] b=Base64.decode(saved,Base64.NO_WRAP);if(b.length==6)return b;}catch(Exception ignored){}
        byte[] b=new byte[6];new SecureRandom().nextBytes(b);b[0]=(byte)((b[0]&0xfc)|2);
        p.edit().putString("identity",Base64.encodeToString(b,Base64.NO_WRAP)).apply();return b;
    }
    private int bootCount(){return Settings.Global.getInt(getContentResolver(),Settings.Global.BOOT_COUNT,-1);}
    @Override public IBinder onBind(Intent intent){return binder;}
    @Override public int onStartCommand(Intent i,int flags,int startId){
        if(!foreground){
            if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){stopSelf();return START_NOT_STICKY;}
            startForeground(41,notification());foreground=true;
        }
        return START_NOT_STICKY; // No hidden auto-restart or camera command replay.
    }
    private Notification notification(){
        Intent i=new Intent(this,MainActivity.class);PendingIntent p=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,"camera").setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("SportCam · "+MatchClock.format(clock.elapsed(SystemClock.elapsedRealtime())))
            .setContentText("Kamerastatus in der App prüfen · "+clock.phase()).setContentIntent(p).setOngoing(true).build();
    }
    private final Runnable tick=new Runnable(){public void run(){
        if(destroyed)return;
        long now=SystemClock.elapsedRealtime();
        if(now-lastCheckpoint>=5000){persist();lastCheckpoint=now;if(foreground)getSystemService(NotificationManager.class).notify(41,notification());}
        changed(null);main.postDelayed(this,500);
    }};
    @Override public void changed(DjiBleCamera c){if(uiListener!=null)uiListener.run();}
    @Override public void log(String side,String message){
        logLines.add(java.time.LocalTime.now().withNano(0)+" "+side+" · "+message);
        if(logLines.size()>300)logLines.remove(0);changed(null);
    }
    @Override public void telemetry(DjiBleCamera c,DjiProtocol.Status st,long mono,long utc){
        Boolean old=observedRecording.put(c.side,st.recording());
        if(old==null||old!=st.recording()){
            JSONObject item=new JSONObject();put(item,"id",UUID.randomUUID().toString());put(item,"side",c.side);
            put(item,"recording_observed",st.recording());put(item,"received_monotonic_ms",mono);put(item,"received_at",Instant.ofEpochMilli(utc).toString());
            put(item,"camera_record_seconds",st.recordSeconds);put(item,"match_elapsed_ms",clock.elapsed(mono));
            put(item,"accuracy","camera-status observation; not a frame-exact start/stop or file index");observations.put(item);persist();
        }
        if(c.authenticated)getSharedPreferences("camera",0).edit().putString(c.side,c.address).putBoolean("paired:"+c.address,true).apply();
    }
    public boolean permissions(){return Build.VERSION.SDK_INT<31 ? checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED : (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED);}
    @android.annotation.SuppressLint("MissingPermission")
    public void scan(){
        if(!permissions()){log("APP","Bluetooth-Berechtigung fehlt");return;}
        stopScan();found.clear();BluetoothManager manager=getSystemService(BluetoothManager.class);BluetoothAdapter adapter=manager==null?null:manager.getAdapter();
        if(adapter==null||!adapter.isEnabled()){log("APP","Bluetooth bitte einschalten");return;}
        scanner=adapter.getBluetoothLeScanner();if(scanner==null){log("APP","BLE-Scanner nicht verfügbar");return;}
        scanning=true;scanner.startScan(null,new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),scanCallback);
        log("APP","Suche DJI-Geräte (12 Sekunden) …");main.postDelayed(this::stopScan,12000);
    }
    @android.annotation.SuppressLint("MissingPermission")
    public void stopScan(){if(scanner!=null){try{scanner.stopScan(scanCallback);}catch(RuntimeException ignored){}}scanning=false;changed(null);}
    private final ScanCallback scanCallback=new ScanCallback(){
        @Override public void onScanResult(int type,ScanResult result){main.post(()->{
            if(!scanning)return;ScanRecord record=result.getScanRecord();if(record==null)return;
            String name=record.getDeviceName();boolean dji=name!=null&&(name.toLowerCase(Locale.ROOT).contains("osmo")||name.toLowerCase(Locale.ROOT).contains("dji"));
            if(record.getServiceUuids()!=null)for(ParcelUuid id:record.getServiceUuids())if(id.toString().startsWith("0000fff0"))dji=true;
            // Android strips the 0x08AA manufacturer id from manufacturer-specific payload.
            byte[] manufacturer=record.getManufacturerSpecificData(0x08aa);
            if(manufacturer!=null&&manufacturer.length>=3&&(manufacturer[2]&255)==0xfa)dji=true;
            if(dji){found.put(result.getDevice().getAddress(),result.getDevice());changed(null);}
        });}
        @Override public void onScanFailed(int code){main.post(()->{scanning=false;log("APP","Scan fehlgeschlagen: "+code);});}
    };
    public void connect(String side,BluetoothDevice device){
        stopScan();for(DjiBleCamera c:cameras.values())if(!c.side.equals(side)&&c.address.equals(device.getAddress())&&(c.authenticated||c.connecting)){log("APP","Dasselbe Gerät nicht beiden Seiten zuordnen");return;}
        observedRecording.remove(side);
        cameras.get(side).connect(device,!getSharedPreferences("camera",0).getBoolean("paired:"+device.getAddress(),false));
    }
    @android.annotation.SuppressLint("MissingPermission")
    public void reconnect(String side){
        String address=getSharedPreferences("camera",0).getString(side,"");
        if(address.isEmpty()){log("APP","Für "+side+" noch kein Gerät gespeichert");return;}
        BluetoothManager manager=getSystemService(BluetoothManager.class);BluetoothAdapter a=manager==null?null:manager.getAdapter();
        if(a==null||!a.isEnabled()){log("APP","Bluetooth bitte einschalten");return;}
        connect(side,a.getRemoteDevice(address));
    }
    public void recordAll(boolean start){
        for(DjiBleCamera c:cameras.values()){
            if(c.authenticated)c.setRecording(start);
            else if(!c.address.isEmpty())log(c.side,"Nicht erreichbar – "+(start?"START":"STOP")+" NICHT gesendet. Kamera vor Ort prüfen.");
        }
        persist();
    }
    public boolean canStart(){
        boolean any=false;
        for(DjiBleCamera c:cameras.values())if(c.authenticated){any=true;if(!c.fresh()||c.commandPending()||!c.status.videoMode()||!c.status.fourK30()||c.status.power==3||c.status.temperature>=2||c.status.freeMb==0)return false;}
        return any;
    }
    public void matchAction(String action){
        if(archiving){log("APP","Archivierung läuft; keine Spieländerung ausgeführt");return;}
        long now=SystemClock.elapsedRealtime();
        try{
            switch(action){
                case "start": if(!canStart())throw new IllegalStateException("Zuerst Kamera verbinden und VIDEO / 4K / 30 einstellen; SD und Temperatur prüfen");clock.start(now);recordAll(true);break;
                case "pause":clock.pause(now);recordAll(false);break;
                case "halftime":clock.halftime(now);recordAll(false);break;
                case "resume":if(!canStart())throw new IllegalStateException("Keine bereite Kamera. Spielzeit bleibt angehalten.");clock.resume(now);recordAll(true);break;
                case "finish":clock.finish(now);recordAll(false);break;
                default:throw new IllegalArgumentException("Unbekannte Aktion");
            }
            JSONObject e=new JSONObject();put(e,"action",action);put(e,"occurred_at",Instant.now().toString());put(e,"monotonic_ms",now);
            put(e,"match_elapsed_ms",clock.elapsed(now));put(e,"phase",clock.phase().name());clockEvents.put(e);
            log("SPIEL",action+" · "+MatchClock.format(clock.elapsed(now))+". Kamerabestätigungen getrennt prüfen.");persist();
        }catch(RuntimeException e){log("APP",e.getMessage());}
    }
    public void marker(String type){
        long now=SystemClock.elapsedRealtime();if(clock.phase()==MatchClock.Phase.READY||clock.phase()==MatchClock.Phase.ENDED){log("APP","Kein aktives Spiel für Videomarker");return;}
        JSONObject m=new JSONObject();put(m,"id",UUID.randomUUID().toString());put(m,"type",type);put(m,"side",selected);
        put(m,"occurred_at",Instant.now().toString());put(m,"monotonic_ms",now);put(m,"match_elapsed_ms",clock.elapsed(now));put(m,"period",clock.period());
        put(m,"source","sportcam_local_video_marker");put(m,"supporter_saved",false);
        JSONObject offsets=new JSONObject();
        for(DjiBleCamera c:cameras.values())if(c.fresh()&&c.status.recording()){
            JSONObject offset=new JSONObject();put(offset,"estimated_recording_ms",c.status.recordSeconds*1000L+now-c.lastStatusMono);
            put(offset,"minimum_uncertainty_ms",1500);put(offset,"file_assignment","not_known");put(offsets,c.side,offset);
        }
        put(m,"camera_offsets",offsets);markers.put(m);log("MARKER",type+" · "+selected+" · nur lokal, kein Supporter-Spielereignis");persist();
    }
    public int markerCount(){return markers.length();}
    public String endpoint(){return getSharedPreferences("supporter",0).getString("endpoint","");}
    public void configure(String id,String title,String endpoint,String newToken) throws Exception {
        if(archiving||syncing)throw new IllegalStateException("Zuerst laufenden Datenabgleich abschließen");
        id=id.trim();endpoint=endpoint.trim();
        if(id.trim().isEmpty())throw new IllegalArgumentException("Spiel-ID fehlt");
        if(!matchId.equals(id)&&(clock.phase()!=MatchClock.Phase.READY||!remote.all().isEmpty()||markers.length()>0))throw new IllegalStateException("Spiel-ID während eines Spiels nicht ändern");
        if(!endpoint.isEmpty())SupporterReader.validateEndpoint(endpoint);
        if(!newToken.isEmpty())new SecureTokenStore(this).save(newToken);
        matchId=id.trim();matchTitle=title.trim().isEmpty()?matchId:title.trim();
        if(!endpoint().equals(endpoint))cursor="";
        getSharedPreferences("supporter",0).edit().putString("endpoint",endpoint).apply();persist();
    }
    public void sync(){
        if(syncing||archiving)return;
        String endpoint=endpoint();if(endpoint.isEmpty()){syncStatus="Noch keine bestätigte Supporter-API hinterlegt";changed(null);return;}
        final String id=matchId,oldCursor=cursor;syncing=true;syncStatus="Lese Supporter-Ereignisse …";changed(null);
        network.execute(()->{
            try{
                String token=new SecureTokenStore(this).read();SupporterReader.Batch batch=SupporterReader.read(endpoint,token,id,oldCursor);
                main.post(()->{
                    syncing=false;if(!matchId.equals(id)){syncStatus="Spiel gewechselt; Antwort verworfen";changed(null);return;}
                    try{remote.apply(matchId,batch.events);cursor=batch.cursor;syncStatus=remote.visible().size()+" Supporter-Ereignisse gelesen · nur lesend";persist();}
                    catch(Exception e){syncStatus="Abgleich abgelehnt: "+e.getMessage();}
                    changed(null);
                });
            }catch(Exception e){main.post(()->{syncing=false;syncStatus="Abgleich nicht möglich: "+e.getMessage();changed(null);});}
        });
    }
    public JSONObject snapshot(){
        long now=SystemClock.elapsedRealtime();JSONObject root=new JSONObject();MatchClock.Snapshot s=clock.snapshot(now);
        put(root,"schema","sportcam.match.v1");put(root,"app_version","0.2.1-dev");put(root,"match_id",matchId);put(root,"title",matchTitle);put(root,"selected",selected);
        put(root,"period",s.period);put(root,"boot_count",bootCount());put(root,"phase",s.phase.name());put(root,"elapsed_ms",s.elapsed);put(root,"monotonic_ms",s.monotonic);
        put(root,"saved_at",Instant.now().toString());put(root,"markers",markers);put(root,"clock_events",clockEvents);put(root,"camera_observations",observations);put(root,"cursor",cursor);
        JSONArray events=new JSONArray();for(EventLedger.Event e:remote.all()){
            JSONObject o=new JSONObject();put(o,"id",e.id);put(o,"revision",e.revision);put(o,"deleted",e.deleted);put(o,"type",e.type);put(o,"label",e.label);
            put(o,"side",e.side);put(o,"occurred_at",e.occurredAt);put(o,"match_elapsed_ms",e.matchMillis);put(o,"period",e.period);events.put(o);
        }
        put(root,"supporter_events",events);put(root,"recent_log",new JSONArray(logLines));
        put(root,"live_view_implemented",true);put(root,"supporter_write_implemented",false);put(root,"hardware_tested",false);return root;
    }
    private static void put(JSONObject o,String key,Object value){try{o.put(key,value);}catch(JSONException e){throw new IllegalArgumentException(e);}}
    public void persist(){
        if(store==null||destroyed||!storageWritable)return;
        final byte[] bytes=snapshot().toString().getBytes(StandardCharsets.UTF_8);
        io.execute(()->{FileOutputStream out=null;try{out=store.startWrite();out.write(bytes);store.finishWrite(out);}catch(Exception e){if(out!=null)store.failWrite(out);main.post(()->log("APP","Speichern fehlgeschlagen – Daten exportieren"));}});
    }
    private void restore(){
        matchId="local-"+UUID.randomUUID();
        if(!store.getBaseFile().exists())return;
        try{
            JSONObject root=new JSONObject(new String(store.readFully(),StandardCharsets.UTF_8));
            if(!"sportcam.match.v1".equals(root.getString("schema")))throw new IOException("Unbekanntes Datenformat");
            String restoredId=root.getString("match_id"),restoredTitle=root.getString("title");
            if(restoredId.trim().isEmpty())throw new IOException("Spiel-ID fehlt");
            String restoredSide=root.optString("selected","LEFT");
            if(!restoredSide.equals("LEFT")&&!restoredSide.equals("RIGHT"))restoredSide="LEFT";
            int savedBoot=root.getInt("boot_count"),currentBoot=bootCount();
            MatchClock.Snapshot snap=new MatchClock.Snapshot(MatchClock.Phase.valueOf(root.getString("phase")),root.getLong("elapsed_ms"),root.getLong("monotonic_ms"),root.getInt("period"));
            long now=SystemClock.elapsedRealtime();boolean sameBoot=savedBoot>=0&&savedBoot==currentBoot;
            MatchClock validation=new MatchClock();validation.restore(snap,now,sameBoot);
            JSONArray restoredMarkers=root.getJSONArray("markers"),restoredClockEvents=root.getJSONArray("clock_events"),restoredObservations=root.getJSONArray("camera_observations");
            String restoredCursor=root.optString("cursor","");
            JSONObject events=new JSONObject();put(events,"schema",SupporterReader.SCHEMA);put(events,"match_id",restoredId);put(events,"events",root.getJSONArray("supporter_events"));put(events,"next_cursor",restoredCursor);
            SupporterReader.Batch batch=SupporterReader.parse(events,restoredId);
            EventLedger validationLedger=new EventLedger();validationLedger.apply(restoredId,batch.events);
            // Commit only after the complete snapshot has been validated.
            clock.restore(snap,now,sameBoot);remote.apply(restoredId,batch.events);
            matchId=restoredId;matchTitle=restoredTitle;selected=restoredSide;
            markers=restoredMarkers;clockEvents=restoredClockEvents;observations=restoredObservations;cursor=restoredCursor;
            log("APP","Spielstand wiederhergestellt; Kameras müssen neu verbunden werden");
        }catch(Exception e){
            File recovery=new File(getFilesDir(),"match-state-recovery-"+System.currentTimeMillis()+".json");
            try{
                java.nio.file.Files.copy(store.getBaseFile().toPath(),recovery.toPath());
                log("APP","Vorheriger Speicherstand nicht lesbar; Original intern gesichert. Neue Sitzung gestartet.");
            }catch(Exception backupError){
                storageWritable=false;
                log("APP","Speicherstand beschädigt und Sicherung fehlgeschlagen. Automatisches Speichern GESPERRT; Daten exportieren.");
            }
        }
    }
    public void newMatch(){
        if(archiving||syncing){log("APP","Zuerst laufenden Datenabgleich abschließen");return;}
        if(clock.phase()!=MatchClock.Phase.ENDED && clock.phase()!=MatchClock.Phase.READY){log("APP","Zuerst SPIELENDE drücken");return;}
        for(DjiBleCamera c:cameras.values())if(c.commandPending()||(c.authenticated && (!c.fresh()||c.status.recording()))){log("APP","Zuerst Kamerastopp bestätigen lassen");return;}
        final byte[] bytes=snapshot().toString().getBytes(StandardCharsets.UTF_8);
        final File archive=new File(getFilesDir(),"archive-"+System.currentTimeMillis()+".json");
        archiving=true;log("APP","Bisheriges Spiel wird lokal archiviert");
        io.execute(()->{
            AtomicFile af=new AtomicFile(archive);FileOutputStream out=null;
            try{
                out=af.startWrite();out.write(bytes);af.finishWrite(out);
                main.post(()->{
                    if(destroyed)return;
                    clock.reset();remote.clear();markers=new JSONArray();clockEvents=new JSONArray();observations=new JSONArray();observedRecording.clear();cursor="";
                    matchId="local-"+UUID.randomUUID();matchTitle="Neues Spiel";syncStatus="Supporter-Spiel-ID neu zuordnen";archiving=false;
                    log("APP","Neues Spiel angelegt; vorheriges intern archiviert");persist();
                });
            }catch(Exception e){if(out!=null)af.failWrite(out);main.post(()->{archiving=false;log("APP","Archivierung fehlgeschlagen. Bisheriges Spiel bleibt erhalten.");});}
        });
    }
    public void shutdown(){persist();stopScan();for(DjiBleCamera c:cameras.values())c.disconnect();stopForeground(STOP_FOREGROUND_REMOVE);foreground=false;stopSelf();}
    @Override public void onDestroy(){
        persist();destroyed=true;main.removeCallbacks(tick);stopScan();for(DjiBleCamera c:cameras.values())c.disconnect();io.shutdown();network.shutdown();super.onDestroy();
    }
}
