package de.bobrad.sportcam.live;

import android.content.Context;
import android.net.*;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.*;
import android.view.Surface;

/** Main-thread lifecycle owner. Old callbacks cannot relabel the other camera as live. */
public final class PreviewConnection implements AutoCloseable {
    private final ConnectivityManager cm;private final Handler main=new Handler(Looper.getMainLooper());
    private ConnectivityManager.NetworkCallback callback;private Action4Preview session;private Thread worker;private int generation;private boolean waiting;
    public PreviewConnection(Context c){cm=c.getSystemService(ConnectivityManager.class);}
    public void start(String ssid,String password,String ip,String identity,Surface output,Action4Preview.Listener listener){
        close();final int tag=generation;
        if(!ip.matches("192\\.168\\.\\d{1,3}\\.\\d{1,3}"))throw new IllegalArgumentException("Nur lokale 192.168.x.x-Kameraadresse zulässig");
        for(String part:ip.split("\\."))if(Integer.parseInt(part)>255)throw new IllegalArgumentException("Ungültige Kamera-IP");
        if(Build.VERSION.SDK_INT<29){
            listener.status("Android 8/9: Kamera-WLAN vorher in den Android-Einstellungen verbinden",false);
            for(Network n:cm.getAllNetworks()){NetworkCapabilities c=cm.getNetworkCapabilities(n);if(c!=null&&c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)){launch(n,ip,identity,output,tag,listener);return;}}
            listener.status("Kein Kamera-WLAN verbunden",false);return;
        }
        WifiNetworkSpecifier spec=new WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(password).build();
        NetworkRequest request=new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build();
        callback=new ConnectivityManager.NetworkCallback(){
            @Override public void onAvailable(Network n){main.post(()->{if(tag==generation){waiting=false;launch(n,ip,identity,output,tag,listener);}});}
            @Override public void onUnavailable(){main.post(()->{if(tag==generation){close();listener.status("WLAN-Verbindung abgelehnt oder nicht erreichbar",false);}});}
            @Override public void onLost(Network n){main.post(()->{if(tag==generation){close();listener.status("Kamera-WLAN getrennt · Bluetoothstatus separat prüfen",false);}});}
        };
        listener.status("Android-WLAN-Freigabe für "+ssid+" bestätigen",false);
        try{waiting=true;cm.requestNetwork(request,callback,20000);}catch(RuntimeException e){close();throw e;}
    }
    private void launch(Network n,String ip,String id,Surface surface,int tag,Action4Preview.Listener l){
        if(tag!=generation)return;if(session!=null)session.close();
        session=new Action4Preview(n,surface,ip,id,new Action4Preview.Listener(){
            @Override public void status(String s,boolean fresh){main.post(()->{if(tag==generation)l.status(s,fresh);});}
            @Override public void frameSize(int w,int h){main.post(()->{if(tag==generation)l.frameSize(w,h);});}
        });
        final Action4Preview next=session;final Thread previous=worker;
        worker=new Thread(()->{
            try{
                if(previous!=null){previous.join(2000);if(previous.isAlive()){next.close();main.post(()->{if(tag==generation)l.status("Vorherige Vorschau noch nicht beendet · erneut verbinden",false);});return;}}
                if(!next.isStopped())next.run();
            }catch(InterruptedException e){Thread.currentThread().interrupt();next.close();}
        },"sportcam-live");worker.start();
    }
    /** Waits briefly for the worker so the Surface is not released while the decoder still writes to it. */
    public void awaitStopped(long ms){Thread t=worker;if(t!=null&&t!=Thread.currentThread())try{t.join(ms);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
    public boolean waitingForNetwork(){return waiting;}
    @Override public void close(){generation++;waiting=false;if(session!=null){session.close();session=null;}ConnectivityManager.NetworkCallback c=callback;callback=null;if(c!=null)try{cm.unregisterNetworkCallback(c);}catch(RuntimeException ignored){}}
}
