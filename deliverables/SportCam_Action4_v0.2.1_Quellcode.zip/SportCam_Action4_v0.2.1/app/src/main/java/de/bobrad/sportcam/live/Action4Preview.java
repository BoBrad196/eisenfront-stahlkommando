package de.bobrad.sportcam.live;

import android.net.Network;
import android.view.Surface;
import de.bobrad.sportcam.core.*;
import java.io.IOException;
import java.net.*;
import java.security.SecureRandom;
import java.util.*;

/** Single-camera preview session. Own Wi-Fi sockets; no bindProcessToNetwork and no BLE commands.
 * Adapted protocol from osmo-client, MIT (THIRD_PARTY_NOTICES.md).
 * Hardware verification on an Action 4 is still required.
 */
public final class Action4Preview implements Runnable,AutoCloseable {
    public interface Listener {void status(String message,boolean hasFreshImage);void frameSize(int width,int height);}
    private static final byte[] EMPTY=new byte[0];
    private final Network network;private final Surface surface;private final String host,identity;private final Listener listener;
    private final byte[] receiveBuffer=new byte[65535];
    private final DatagramPacket receivePacket=new DatagramPacket(receiveBuffer,receiveBuffer.length);
    private volatile boolean stopped;private volatile DatagramSocket udp;private volatile Socket tcp;
    private final int session,base;private int linkSeq,dataSeq,count,messageSeq=0xa000,videoCursor,dataCursor,extraCursor,tick;
    private long lastVideo,lastRendered,lastReport,packets,frames;private boolean staleReported;
    private final List<Pending> pending=new ArrayList<>();private boolean sawAck;private long lastAck;
    private static final class Pending {final int seq;final byte[] bytes;long sent;Pending(int s,byte[] b,long t){seq=s;bytes=b;sent=t;}}
    public Action4Preview(Network net,Surface output,String ip,String identity,Listener l){
        network=net;surface=output;host=ip;this.identity=identity;listener=l;
        SecureRandom r=new SecureRandom();session=0x1000+r.nextInt(0xeffe);base=(0x1000+r.nextInt(0xe000))&0xfff8;dataCursor=extraCursor=base;
    }
    private static long millis(){return android.os.SystemClock.elapsedRealtime();}
    @Override public void run(){
        try(PreviewDecoder decoder=new PreviewDecoder(surface,(n,w,h)->{
            frames=n;lastRendered=millis();staleReported=false;
            if(lastRendered-lastReport>=500){lastReport=lastRendered;listener.frameSize(w,h);listener.status("LIVE · "+w+" × "+h+" · "+n+" Bilder",true);}
        })){
            if(stopped)return;
            listener.status("WLAN verbunden · Kamerakopplung bestätigen, falls angezeigt",false);
            poke();if(stopped)return;
            DatagramSocket local=new DatagramSocket(null);udp=local;
            if(stopped){local.close();return;}
            local.setReceiveBufferSize(2*1024*1024);local.bind(new InetSocketAddress(0));network.bindSocket(local);local.connect(InetAddress.getByName(host),9004);local.setSoTimeout(50);
            handshake();if(stopped)return;
            startStream();listener.status("Livebild angefordert · warte auf decodierbare Bilder",false);
            VideoAssembler assembler=new VideoAssembler((b,t)->{try{decoder.accept(b,t);}catch(Exception e){throw new DecodeFailure(e);}});
            long now=millis(),started=now,nextAck=now,nextBeat=now+200,lastRefresh=now;
            lastVideo=now;local.setSoTimeout(10);
            while(!stopped){
                now=millis();
                if(now>=nextAck){sendLink(4,WifiProtocol.ack(videoCursor,dataCursor,extraCursor));resend(now);nextAck=now+25;}
                if(now>=nextBeat){heartbeat();nextBeat=now+200;}
                byte[] b=receive();
                if(b!=null&&WifiProtocol.validLink(b)){
                    packets++;int seq=WifiProtocol.u16(b,4),kind=b[6]&255;
                    if(kind==2&&b.length>=20){videoCursor=seq;lastVideo=now;assembler.accept(seq,Arrays.copyOfRange(b,20,b.length),System.nanoTime());}
                    else{
                        if(kind==1&&b.length>=34){if(now-lastVideo>500)videoCursor=WifiProtocol.u16(b,10);dataCursor=WifiProtocol.u16(b,18);extraCursor=WifiProtocol.u16(b,26);acknowledged(extraCursor,now);}
                        else if(kind==3)dataCursor=seq;
                        for(WifiProtocol.Message m:WifiProtocol.messages(b,8,b.length-8))if(m.needsReply())answer(m);
                    }
                }
                decoder.drain();
                long last=lastRendered==0?started:lastRendered;
                if(now-last>2500&&!staleReported){staleReported=true;listener.status("KEIN AKTUELLES LIVEBILD · Aufnahmezustand separat prüfen",false);}
                if(now-last>5000&&now-lastRefresh>5000){send(0x41,9,0xa8,0x40,WifiProtocol.LIVE_REQUEST);lastRefresh=now;}
                if(now-last>20000)throw new IOException("Kein decodiertes Livebild. Empfang: "+packets+" Pakete, "+assembler.completed+" vollständige Frames, "+assembler.dropped+" verworfen. Mimo schließen, WLAN/Passwort und Kameradisplay prüfen.");
            }
        }catch(Exception e){if(!stopped){String msg=e.getCause()!=null?e.getCause().getMessage():e.getMessage();listener.status("Livebildfehler: "+(msg==null?e.getClass().getSimpleName():msg),false);}}
        finally{close();}
    }
    private static final class DecodeFailure extends RuntimeException {DecodeFailure(Exception e){super(e);}}
    private void poke() throws Exception {
        Socket s=new Socket();tcp=s;
        try{if(stopped)return;network.bindSocket(s);s.connect(new InetSocketAddress(host,7001),1500);s.getOutputStream().write(WifiProtocol.pairing(identity).encode());s.getOutputStream().flush();Thread.sleep(400);}
        catch(IOException ignored){/* Some firmware already exposes its datalink without a successful poke. */}
        finally{try{s.close();}catch(IOException ignored){}tcp=null;}
    }
    private void handshake() throws Exception {
        byte[] body=WifiProtocol.handshake(base);
        for(int attempt=0;attempt<30&&!stopped;attempt++){
            sendLink(0,body);long end=millis()+350;
            while(!stopped&&millis()<end){byte[] b=receive();if(b!=null&&WifiProtocol.validLink(b)&&(b[6]&255)==0){linkSeq=dataSeq=(base+8)&65535;return;}}
        }
        if(!stopped)throw new IOException("Kamera antwortet nicht auf den WLAN-Handshake (UDP 9004)");
    }
    private void startStream() throws IOException {
        send(1,0,0x81,0x40,WifiProtocol.REGISTER);
        byte[] source=new byte[11];source[10]=3;send(1,2,9,0x40,source);
        send(0x41,9,0xa8,0x40,WifiProtocol.LIVE_REQUEST);
        send(0x48,0,0x81,0x80,WifiProtocol.APP_INFO);
        send(0x28,0,0x88,0x40,WifiProtocol.ENCODER_REGISTER);trigger();
    }
    private void trigger() throws IOException {send(0x48,0,0x81,0x80,WifiProtocol.APP_INFO);send(0x48,0,0x82,0x80,new byte[]{0});}
    private void heartbeat() throws IOException {tick++;byte[] b={1,0,(byte)((tick/2)&255),0,0,-1,-1,-1,-1};send(0x48,0,0x4f,0x40,b);if(tick%5==0)send(0x28,0,0x88,0x40,WifiProtocol.ENCODER_REGISTER);if(tick%10==0)trigger();}
    private void answer(WifiProtocol.Message m) throws IOException {
        byte[] b=m.set==0&&m.command==0x81?WifiProtocol.APP_INFO:(m.set==0&&m.command==0x88&&m.payload.length>0&&(m.payload[0]&255)==0x19?new byte[]{0x1a,0,0,0,0}:new byte[]{0});
        sendMessage(new WifiProtocol.Message(2,m.from,m.sequence,0x80,m.set,m.command,b));
    }
    private void send(int to,int set,int cmd,int flags,byte[] b) throws IOException {sendMessage(new WifiProtocol.Message(2,to,messageSeq,flags,set,cmd,b));messageSeq=(messageSeq+1)&65535;}
    private void sendMessage(WifiProtocol.Message m) throws IOException {
        byte[] p=WifiProtocol.link(5,session,dataSeq,WifiProtocol.routed(dataSeq,count,m));sendRaw(p);pending.add(new Pending(dataSeq,p,millis()));if(pending.size()>256)pending.remove(0);dataSeq=(dataSeq+8)&65535;count=(count+1)&255;
    }
    private void sendLink(int kind,byte[] body) throws IOException {sendRaw(WifiProtocol.link(kind,session,linkSeq,body));linkSeq=(linkSeq+8)&65535;}
    private void sendRaw(byte[] b) throws IOException {if(!stopped)udp.send(new DatagramPacket(b,b.length));}
    private byte[] receive() throws IOException {receivePacket.setLength(receiveBuffer.length);try{udp.receive(receivePacket);return Arrays.copyOf(receiveBuffer,receivePacket.getLength());}catch(SocketTimeoutException timeout){return null;}}
    private void acknowledged(int cursor,long now){for(int i=0;i<pending.size();i++)if(pending.get(i).seq==cursor){pending.subList(0,i+1).clear();sawAck=true;lastAck=now;return;}}
    private void resend(long now) throws IOException {if(!sawAck||pending.isEmpty()||now-pending.get(0).sent<300||now-lastAck>5000)return;for(Pending p:pending){sendRaw(p.bytes);p.sent=now;}}
    public boolean isStopped(){return stopped;}
    @Override public void close(){stopped=true;DatagramSocket u=udp;if(u!=null)u.close();Socket t=tcp;if(t!=null)try{t.close();}catch(IOException ignored){}}
}
