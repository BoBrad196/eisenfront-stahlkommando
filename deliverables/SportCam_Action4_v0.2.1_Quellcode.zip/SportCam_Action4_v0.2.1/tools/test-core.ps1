$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
New-Item -ItemType Directory -Force ".test-classes" | Out-Null
$Sources = @(Get-ChildItem "app/src/main/java/de/bobrad/sportcam/core/*.java" | ForEach-Object { $_.FullName })
& javac --release 17 -d .test-classes @Sources tests/CoreTests.java tests/WifiTests.java tests/SyntaxCheck.java
if ($LASTEXITCODE -ne 0) { throw "Kompilierung der Kerntests fehlgeschlagen" }
& java -cp .test-classes CoreTests
if ($LASTEXITCODE -ne 0) { throw "Kerntests fehlgeschlagen" }
& java -cp .test-classes WifiTests
if ($LASTEXITCODE -ne 0) { throw "WLAN/Videotests fehlgeschlagen" }
& java -cp .test-classes SyntaxCheck
if ($LASTEXITCODE -ne 0) { throw "Syntaxpruefung fehlgeschlagen" }
