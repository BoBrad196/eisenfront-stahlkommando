package de.bobrad.sportcam;

import android.Manifest;
import android.app.*;
import android.bluetooth.BluetoothDevice;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import de.bobrad.sportcam.core.*;
import de.bobrad.sportcam.live.*;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Native Android UI; no external WebView, no simulated camera success or stock live image. */
public final class MainActivity extends Activity {
    private static final int BG=0xff101923,CARD=0xff1c2b3b,FG=0xfff0f4f8,MUTED=0xffb6c5d5,ACCENT=0xffff963d;
    private SportCamService svc;private boolean bound=false;
    private LinearLayout root;
    private TextView title,timer,phase,live,sync,counts,log,events;
    private final Map<String,TextView> cameraLabels=new LinkedHashMap<>();
    private Button start,pause,half,resume,end;
    private byte[] pendingExport;
    private TextureView video;
    private Surface videoSurface;
    private PreviewConnection preview;
    private WifiProfiles wifiProfiles;
    private boolean previewRequested;
    private int videoWidth=16,videoHeight=9;
    private String previewText="Livebild nicht verbunden";
    private final ServiceConnection connection=new ServiceConnection(){
        public void onServiceConnected(ComponentName n,IBinder b){svc=((SportCamService.LocalBinder)b).get();svc.uiListener=MainActivity.this::render;render();}
        public void onServiceDisconnected(ComponentName n){svc=null;render();}
    };
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        preview=new PreviewConnection(this);wifiProfiles=new WifiProfiles(this);
        makeUi();bound=bindService(new Intent(this,SportCamService.class),connection,Context.BIND_AUTO_CREATE);
    }
    private int dp(int n){return Math.round(getResources().getDisplayMetrics().density*n);}
    private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(size);t.setPadding(0,dp(4),0,dp(4));return t;}
    private GradientDrawable box(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(12));return d;}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(12),dp(16),dp(12));l.setBackground(box(CARD));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(12);root.addView(l,p);return l;}
    private LinearLayout row(LinearLayout parent){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);parent.addView(r,new LinearLayout.LayoutParams(-1,-2));return r;}
    private Button button(LinearLayout parent,String label,Runnable action){
        Button b=new Button(this);b.setText(label);b.setTextColor(FG);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(dp(52));
        b.setOnClickListener(v->{try{if(svc==null){toast("App-Verbindung wird aufgebaut");return;}action.run();render();}catch(Exception e){toast(e.getMessage()==null?"Aktion fehlgeschlagen":e.getMessage());}});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(parent.getOrientation()==LinearLayout.HORIZONTAL?0:-1,-2,parent.getOrientation()==LinearLayout.HORIZONTAL?1:0);p.setMargins(dp(2),dp(3),dp(2),dp(3));parent.addView(b,p);return b;
    }
    private void makeUi(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(16),dp(16),dp(24));scroll.addView(root);
        scroll.setOnApplyWindowInsetsListener((v,insets)->{root.setPadding(dp(16),dp(16)+insets.getSystemWindowInsetTop(),dp(16),dp(24)+insets.getSystemWindowInsetBottom());return insets;});
        root.addView(text("SportCam",30,FG));root.addView(text("ACTION 4 · FOOTBALL CONTROLLER",12,ACCENT));
        root.addView(text("v0.2 · Experimentelle WLAN-Vorschau\nAndroid-Build und Action-4-Hardwaretest noch offen.",13,MUTED));
        LinearLayout match=card();title=text("Spiel",18,FG);match.addView(title);
        timer=text("00:00",52,FG);timer.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);match.addView(timer);
        phase=text("Noch nicht gestartet",15,MUTED);match.addView(phase);
        LinearLayout selectors=row(match);button(selectors,"LEFT CAM",()->selectPreview("LEFT"));button(selectors,"RIGHT CAM",()->selectPreview("RIGHT"));
        FrameLayout screen=new FrameLayout(this);screen.setBackgroundColor(0xff07101a);
        video=new TextureView(this);screen.addView(video,new FrameLayout.LayoutParams(-1,-1));
        live=text("Livebild nicht verbunden",14,FG);live.setGravity(Gravity.CENTER);live.setPadding(dp(12),dp(8),dp(12),dp(8));live.setBackgroundColor(0xe007101a);
        screen.addView(live,new FrameLayout.LayoutParams(-1,-1));match.addView(screen,new LinearLayout.LayoutParams(-1,dp(220)));
        video.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(SurfaceTexture t,int w,int h){videoSurface=new Surface(t);resizeVideo();if(previewRequested)startPreview();}
            public void onSurfaceTextureSizeChanged(SurfaceTexture t,int w,int h){resizeVideo();}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture t){stopPreview("Vorschau beendet");if(preview!=null)preview.awaitStopped(500);if(videoSurface!=null){videoSurface.release();videoSurface=null;}return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture t){}
        });
        LinearLayout vr=row(match);button(vr,"LIVE verbinden",this::startPreview);button(vr,"LIVE trennen",()->stopPreview("Livebild getrennt · Aufnahme unverändert"));
        button(match,"WLAN der ausgewählten Kamera einrichten",this::wifiSettings);
        match.addView(text("Nur eine Vorschau zur Zeit. Wechsel kann eine Android-WLAN-Freigabe verlangen. LIVE trennen sendet keinen Aufnahme-Stopp.",12,MUTED));
        for(String side:new String[]{"LEFT","RIGHT"}){
            LinearLayout cam=card();cam.addView(text(side+" CAM",16,ACCENT));TextView t=text("Nicht verbunden",14,FG);cam.addView(t);cameraLabels.put(side,t);
            LinearLayout controls=row(cam);button(controls,"Gerät auswählen",()->chooseDevice(side));button(controls,"Neu verbinden",()->{if(ensureBluetooth())svc.reconnect(side);});
            LinearLayout manual=row(cam);button(manual,"Aufnahme starten",()->svc.cameras.get(side).setRecording(true));button(manual,"Aufnahme stoppen",()->svc.cameras.get(side).setRecording(false));
            button(cam,"Verbindung trennen",()->confirm("Bluetooth trennen?","Eine laufende Kameraaufnahme wird dadurch NICHT gestoppt.",()->svc.cameras.get(side).disconnect()));
        }
        LinearLayout controls=card();controls.addView(text("Spiel & Kameras",18,FG));
        button(controls,"Bluetooth freigeben / Kameras suchen",()->{if(ensureBluetooth())svc.scan();});
        start=button(controls,"SPIEL STARTEN · verbundene Kameras",()->svc.matchAction("start"));
        LinearLayout pauses=row(controls);pause=button(pauses,"PAUSE",()->svc.matchAction("pause"));half=button(pauses,"HALBZEIT / PAUSE",()->svc.matchAction("halftime"));
        resume=button(controls,"FORTSETZEN",()->svc.matchAction("resume"));
        end=button(controls,"SPIELENDE",()->confirm("Spiel beenden?","Die Spielzeit wird eingefroren. Stopps werden an verbundene Kameras gesendet; Rückmeldungen bitte prüfen.",()->svc.matchAction("finish")));
        controls.addView(text("Die Uhr und Kameras haben getrennte Zustände. Bei fehlendem STOP-ACK kann eine Kamera weiter aufnehmen.",12,MUTED));
        LinearLayout local=card();local.addView(text("Videomarker · nur lokal",18,FG));
        LinearLayout markers=row(local);button(markers,"TOR",()->svc.marker("TOR"));button(markers,"CHANCE",()->svc.marker("CHANCE"));button(markers,"FOUL",()->svc.marker("FOUL"));
        counts=text("0 lokale Marker",13,MUTED);local.addView(counts);
        local.addView(text("Keine zweite Ergebnisverwaltung: Diese Marker werden NICHT als Tore oder Ereignisse an die Supporter-App gesendet.",12,MUTED));
        LinearLayout supporter=card();supporter.addView(text("Supporter-App",18,FG));sync=text("Schnittstelle noch nicht angebunden",14,MUTED);supporter.addView(sync);
        LinearLayout sr=row(supporter);button(sr,"Supporter öffnen",()->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.tsvkirberg.de/index.php?option=com_bobradseason&view=supporter"))));button(sr,"Ereignisse lesen",()->svc.sync());
        button(supporter,"Spiel / geprüfte API konfigurieren",this::settings);
        supporter.addView(text("Serveradresse, Anmeldung und Datenmodell sind noch mit dem echten FootballSeason-Quellcode abzugleichen. Standardmäßig keine API-Verbindung.",12,MUTED));
        events=text("Noch keine importierten Ereignisse",13,FG);supporter.addView(events);
        LinearLayout data=card();button(data,"Spielprotokoll als JSON exportieren",this::export);
        button(data,"Neues Spiel anlegen",()->confirm("Neues Spiel?","Nur nach Spielende möglich. Das bisherige Spiel wird zusätzlich lokal archiviert; exportiere wichtige Daten vorher.",()->{svc.newMatch();render();}));
        button(data,"App-Verbindungen beenden",()->confirm("SportCam beenden?","Eine noch laufende Kameraaufnahme wird NICHT automatisch gestoppt. Vorher den Status beider Kameras prüfen.",()->{svc.shutdown();finish();}));
        data.addView(text("Protokoll",16,FG));log=text("",12,MUTED);log.setTypeface(Typeface.MONOSPACE);data.addView(log);
        setContentView(scroll);
    }
    private void render(){
        if(svc==null)return;
        title.setText(svc.matchTitle);timer.setText(MatchClock.format(svc.clock.elapsed(SystemClock.elapsedRealtime())));
        phase.setText(phaseLabel(svc.clock.phase()));
        live.setText(svc.selected+" CAM\n"+previewText);
        for(DjiBleCamera c:svc.cameras.values()){
            String t=c.label;
            if(c.authenticated&&!c.fresh())t="Verbindung vorhanden · Status veraltet/unbekannt";
            if(c.fresh())t+="\nAkku "+c.status.battery+" % · SD "+c.status.freeMb+" MB\n"+(c.status.fourK30()?"4K / 30 bestätigt":"4K / 30 an Kamera prüfen")+" · Aufnahme "+MatchClock.format(c.status.recordSeconds*1000L);
            t+="\nBefehl: "+c.lastCommand;cameraLabels.get(c.side).setText(t);
        }
        MatchClock.Phase p=svc.clock.phase();
        start.setEnabled(p==MatchClock.Phase.READY);pause.setEnabled(svc.clock.running());half.setEnabled(p==MatchClock.Phase.FIRST||p==MatchClock.Phase.PAUSED_FIRST);
        resume.setEnabled(p==MatchClock.Phase.HALFTIME||p==MatchClock.Phase.PAUSED_FIRST||p==MatchClock.Phase.PAUSED_SECOND);
        resume.setText(p==MatchClock.Phase.HALFTIME?"2. HALBZEIT STARTEN · ohne Zeitreset":"FORTSETZEN · ohne Zeitreset");
        end.setEnabled(p!=MatchClock.Phase.READY&&p!=MatchClock.Phase.ENDED);
        sync.setText(svc.syncStatus+(svc.scanning?"\nBluetooth-Suche läuft …":""));counts.setText(svc.markerCount()+" lokale Videomarker · Auswahl "+svc.selected);
        StringBuilder e=new StringBuilder();for(EventLedger.Event x:svc.remote.visible())e.append(MatchClock.format(x.matchMillis)).append(" · ").append(x.label).append("\n");
        events.setText(e.length()==0?"Noch keine importierten Ereignisse":e.toString());
        StringBuilder logs=new StringBuilder();for(int i=Math.max(0,svc.logLines.size()-12);i<svc.logLines.size();i++)logs.append(svc.logLines.get(i)).append("\n");log.setText(logs);
    }
    private String phaseLabel(MatchClock.Phase p){
        switch(p){case READY:return "Bereit · 1. Halbzeit";case FIRST:return "1. Halbzeit · läuft";case PAUSED_FIRST:return "1. Halbzeit · Pause";case HALFTIME:return "Halbzeitpause · Uhr angehalten";case SECOND:return "2. Halbzeit · läuft";case PAUSED_SECOND:return "2. Halbzeit · Pause";default:return "Spiel beendet";}
    }
    private boolean ensureBluetooth(){
        ArrayList<String> wanted=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=31){wanted.add(Manifest.permission.BLUETOOTH_SCAN);wanted.add(Manifest.permission.BLUETOOTH_CONNECT);}
        else wanted.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if(Build.VERSION.SDK_INT>=33 && !getPreferences(0).getBoolean("notification_permission_requested",false)){
            wanted.add(Manifest.permission.POST_NOTIFICATIONS);
            getPreferences(0).edit().putBoolean("notification_permission_requested",true).apply();
        }
        ArrayList<String> missing=new ArrayList<>();for(String p:wanted)if(checkSelfPermission(p)!=PackageManager.PERMISSION_GRANTED)missing.add(p);
        if(!missing.isEmpty()){requestPermissions(missing.toArray(new String[0]),10);return false;}
        startForegroundService(new Intent(this,SportCamService.class));return true;
    }
    @Override public void onRequestPermissionsResult(int req,String[] names,int[] grants){
        super.onRequestPermissionsResult(req,names,grants);
        if(req==11){boolean ok=grants.length>0;for(int g:grants)ok&=g==PackageManager.PERMISSION_GRANTED;if(ok)startPreview();else stopPreview("WLAN-Freigabe fehlt");return;}
        if(req==10&&svc!=null){if(svc.permissions()){startForegroundService(new Intent(this,SportCamService.class));svc.scan();}else toast("Bluetooth-Freigabe fehlt. Keine Kamerasteuerung gestartet.");}
    }
    @android.annotation.SuppressLint("MissingPermission")
    private void chooseDevice(String side){
        if(!ensureBluetooth())return;
        if(svc.found.isEmpty()){svc.scan();toast("Suche gestartet. Danach erneut „Gerät auswählen“ drücken.");return;}
        ArrayList<BluetoothDevice> devices=new ArrayList<>(svc.found.values());String[] labels=new String[devices.size()];
        for(int i=0;i<devices.size();i++){BluetoothDevice d=devices.get(i);String name=d.getName();labels[i]=(name==null?"DJI-Kandidat":name)+"\n"+d.getAddress();}
        new AlertDialog.Builder(this).setTitle(side+" CAM zuordnen").setItems(labels,(dialog,index)->svc.connect(side,devices.get(index))).setNegativeButton("Abbrechen",null).show();
    }
    private EditText input(LinearLayout l,String hint,String value,boolean secret){
        EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextColor(FG);e.setHintTextColor(MUTED);e.setSingleLine(true);
        e.setInputType(secret?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_TEXT);l.addView(e);return e;
    }
    private void settings(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(8),dp(16),dp(8));
        EditText id=input(l,"Echte FootballSeason-Spiel-ID",svc.matchId,false),name=input(l,"Begegnung",svc.matchTitle,false);
        EditText endpoint=input(l,"Bestätigter API-Endpunkt (sonst leer lassen)",svc.endpoint(),false),token=input(l,"API-Token (leer = bisherigen behalten)","",true);
        l.addView(text("Kein Supporter-Passwort eintragen. Ein passender API-Token/Endpunkt existiert in diesem Stand noch nicht automatisch.",12,MUTED));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Spiel & lesende Schnittstelle").setView(l).setNegativeButton("Abbrechen",null).setPositiveButton("Speichern",null).create();
        d.setOnShowListener(v->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b->{try{svc.configure(id.getText().toString(),name.getText().toString(),endpoint.getText().toString().trim(),token.getText().toString());d.dismiss();render();}catch(Exception e){toast(e.getMessage());}}));d.show();
    }
    private void export(){
        pendingExport=svc.snapshot().toString().getBytes(StandardCharsets.UTF_8);
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"SportCam-"+System.currentTimeMillis()+".json");startActivityForResult(i,20);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==20&&result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingExport!=null){
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new java.io.IOException("Datei nicht beschreibbar");out.write(pendingExport);toast("Spielprotokoll gespeichert");}
            catch(Exception e){toast("Export fehlgeschlagen: "+e.getMessage());}finally{pendingExport=null;}
        }
    }

    private void selectPreview(String side){
        if(side.equals(svc.selected))return;
        boolean restart=previewRequested;preview.close();svc.selected=side;svc.persist();
        showPreviewStatus("Livebild nicht verbunden",false);
        if(restart)startPreview();
    }
    private void showPreviewStatus(String message,boolean fresh){
        previewText=message;
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,fresh?-2:-1);
        p.gravity=Gravity.BOTTOM;live.setLayoutParams(p);live.setBackgroundColor(fresh?0xbb07101a:0xf007101a);
        live.setText((svc==null?"":svc.selected+" CAM\n")+message);
    }
    private void startPreview(){
        if(svc==null)return;
        String permission=Build.VERSION.SDK_INT>=33?Manifest.permission.NEARBY_WIFI_DEVICES:Manifest.permission.ACCESS_FINE_LOCATION;
        if(checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{permission},11);return;}
        if(wifiProfiles.ssid(svc.selected).isEmpty()){wifiSettings();return;}
        previewRequested=true;if(videoSurface==null){showPreviewStatus("Warte auf Videofläche",false);return;}
        final String side=svc.selected;
        try{
            preview.start(wifiProfiles.ssid(side),wifiProfiles.password(side),wifiProfiles.ip(side),wifiProfiles.identity(),videoSurface,new Action4Preview.Listener(){
                public void status(String message,boolean fresh){if(svc!=null&&side.equals(svc.selected))showPreviewStatus(message,fresh);}
                public void frameSize(int w,int h){videoWidth=w;videoHeight=h;resizeVideo();}
            });
        }catch(Exception e){stopPreview("Livebild: "+e.getMessage());}
    }
    private void stopPreview(String reason){previewRequested=false;if(preview!=null)preview.close();if(live!=null)showPreviewStatus(reason,false);}
    private void resizeVideo(){
        int w=video.getWidth(),h=video.getHeight();if(w<=0||h<=0||videoWidth<=0||videoHeight<=0)return;
        float target=(float)videoWidth/videoHeight,current=(float)w/h;
        Matrix transform=new Matrix();float sx=1,sy=1;if(current>target)sx=target/current;else sy=current/target;
        transform.setScale(sx,sy,w/2f,h/2f);video.setTransform(transform);
    }
    private void wifiSettings(){
        final String side=svc.selected;LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(8),dp(16),dp(8));
        l.addView(text(side+" CAM · WLAN-Daten vom Kameradisplay. DJI Mimo vorher schließen. Kamera-WLAN gegebenenfalls dort aktivieren.",13,MUTED));
        EditText ssid=input(l,"WLAN-Name (SSID)",wifiProfiles.ssid(side),false),pass=input(l,"WLAN-Passwort (leer = bisheriges)","",true),ip=input(l,"Kamera-IP",wifiProfiles.ip(side),false);
        l.addView(text("Passwort verschlüsselt auf diesem Handy. Kein Supporter-Passwort eingeben. Kamerakopplung am Display bestätigen.",12,MUTED));
        AlertDialog d=new AlertDialog.Builder(this).setTitle(side+" Livebild-WLAN").setView(l).setNegativeButton("Abbrechen",null).setPositiveButton("Speichern",null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{wifiProfiles.save(side,ssid.getText().toString(),ip.getText().toString().trim(),pass.getText().toString());stopPreview("WLAN gespeichert · LIVE verbinden drücken");d.dismiss();}catch(Exception e){toast(e.getMessage());}}));d.show();
    }
    @Override protected void onStop(){if(preview==null||!preview.waitingForNetwork())stopPreview("Vorschau im Hintergrund beendet · Kamerasteuerung separat");super.onStop();}

    private void confirm(String title,String message,Runnable yes){new AlertDialog.Builder(this).setTitle(title).setMessage(message).setNegativeButton("Abbrechen",null).setPositiveButton("Bestätigen",(d,w)->{try{yes.run();}catch(Exception e){toast(e.getMessage());}}).show();}
    private void toast(String value){Toast.makeText(this,value==null?"Fehler":value,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){if(preview!=null){preview.close();preview.awaitStopped(500);}if(videoSurface!=null){videoSurface.release();videoSurface=null;}if(svc!=null)svc.uiListener=null;if(bound)unbindService(connection);super.onDestroy();}
}
