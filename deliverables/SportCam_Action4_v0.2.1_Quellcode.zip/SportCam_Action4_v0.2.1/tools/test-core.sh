#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p .test-classes
javac --release 17 -d .test-classes app/src/main/java/de/bobrad/sportcam/core/*.java tests/CoreTests.java tests/WifiTests.java tests/SyntaxCheck.java
java -cp .test-classes CoreTests
java -cp .test-classes WifiTests
java -cp .test-classes SyntaxCheck
