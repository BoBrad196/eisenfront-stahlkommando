import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.nio.file.*;
import java.util.*;

/** Parses Java grammar only. This deliberately does NOT claim Android type/API checking. */
public final class SyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null)throw new IllegalStateException("A full JDK is required");
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        List<java.io.File> files=new ArrayList<>();
        try(var paths=Files.walk(Path.of("app/src/main/java"))){paths.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toFile()));}
        try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,Locale.ROOT,null)){
            var units=manager.getJavaFileObjectsFromFiles(files);
            JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,List.of("--release","17","-proc:none"),null,units);
            task.parse();
            for(var d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR)throw new AssertionError(d.toString());
        }
        System.out.println("PASS: Java grammar parsed for "+files.size()+" app source files. No Android SDK type checking performed.");
    }
}
