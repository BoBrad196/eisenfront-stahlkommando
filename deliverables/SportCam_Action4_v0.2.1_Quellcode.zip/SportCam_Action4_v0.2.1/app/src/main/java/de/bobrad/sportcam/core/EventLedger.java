package de.bobrad.sportcam.core;

import java.util.*;

/** Read-only Supporter mirror. Explicit tombstones prevent deleted events reappearing.
 * Existing events are not deleted just because a page/delta omits them.
 */
public final class EventLedger {
    public static final class Event {
        public final String matchId,id,type,label,side,occurredAt;
        public final long revision,matchMillis; public final boolean deleted; public final int period;
        public Event(String matchId,String id,long revision,boolean deleted,String type,String label,
                     String side,String occurredAt,long matchMillis,int period) {
            if(matchId==null || matchId.trim().isEmpty() || id==null || id.trim().isEmpty() || revision<1 || matchMillis<0
                    || period<1 || period>2 || !Arrays.asList("LEFT","RIGHT","BOTH","UNKNOWN").contains(side)
                    || type==null || label==null || occurredAt==null || id.length()>200 || label.length()>500)
                throw new IllegalArgumentException("Ungültiges Supporter-Ereignis");
            this.matchId=matchId;this.id=id;this.revision=revision;this.deleted=deleted;this.type=type;
            this.label=label;this.side=side;this.occurredAt=occurredAt;this.matchMillis=matchMillis;this.period=period;
        }
        public boolean same(Event b) {
            return b!=null && id.equals(b.id) && matchId.equals(b.matchId) && revision==b.revision && deleted==b.deleted
                && type.equals(b.type) && label.equals(b.label) && side.equals(b.side)
                && occurredAt.equals(b.occurredAt) && matchMillis==b.matchMillis && period==b.period;
        }
    }
    private final Map<String,Event> entries=new LinkedHashMap<>();
    public void apply(String matchId,List<Event> batch) {
        Map<String,Event> next=new LinkedHashMap<>(entries);
        for(Event e:batch) {
            if(!e.matchId.equals(matchId)) throw new IllegalArgumentException("Ereignis gehört zu einem anderen Spiel");
            Event old=next.get(e.id);
            if(old!=null && !old.matchId.equals(e.matchId)) throw new IllegalArgumentException("Spiel-ID-Konflikt");
            if(old!=null && old.revision==e.revision && !old.same(e)) throw new IllegalArgumentException("Inhalt geändert ohne neue Revision");
            if(old==null || old.revision<e.revision) next.put(e.id,e);
        }
        entries.clear(); entries.putAll(next);
    }
    public void clear() { entries.clear(); }
    public List<Event> all() { return new ArrayList<>(entries.values()); }
    public List<Event> visible() {
        List<Event> result=new ArrayList<>();
        for(Event e:entries.values()) if(!e.deleted) result.add(e);
        result.sort(Comparator.comparingLong(e->e.matchMillis)); return result;
    }
}
