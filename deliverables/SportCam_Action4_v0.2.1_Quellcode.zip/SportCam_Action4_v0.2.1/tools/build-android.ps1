$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
if (-not (Get-Command java -ErrorAction SilentlyContinue)) { throw "JDK 17/21 installieren und JAVA_HOME setzen." }
if (-not $env:ANDROID_HOME -and -not (Test-Path "local.properties")) { throw "Android SDK 35 installieren; ANDROID_HOME oder local.properties setzen." }
$Version = "8.9"
$Dir = Join-Path (Get-Location) ".tooling"
New-Item -ItemType Directory -Force $Dir | Out-Null
$Gradle = Join-Path $Dir "gradle-$Version/bin/gradle.bat"
if (-not (Test-Path $Gradle)) {
    $Archive = Join-Path $Dir "gradle-$Version-bin.zip"
    $Url = "https://services.gradle.org/distributions/gradle-$Version-bin.zip"
    Invoke-WebRequest -Uri $Url -OutFile $Archive -UseBasicParsing
    $Expected = (Invoke-WebRequest -Uri "$Url.sha256" -UseBasicParsing).Content.ToString().Trim().ToLowerInvariant()
    $Actual = (Get-FileHash -Path $Archive -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Expected.Length -ne 64 -or $Expected -ne $Actual) { throw "Gradle-Pruefsumme stimmt NICHT." }
    Expand-Archive -Path $Archive -DestinationPath $Dir -Force
}
& $Gradle --no-daemon :app:assembleDebug @args
if ($LASTEXITCODE -ne 0) { throw "Android-Build fehlgeschlagen. Ausgabe pruefen; keine APK bestaetigt." }
Write-Host "APK bei erfolgreichem Build: app/build/outputs/apk/debug/app-debug.apk"
