# Third-party notices

SportCam is independent of DJI. DJI, Osmo and DJI Mimo are their respective owners' trademarks. No DJI endorsement or certification is claimed.

The Action-series Wi-Fi protocol port in WifiProtocol and Action4Preview, and the description used for frame assembly, are based on osmo-client's MIT-licensed implementation and documentation. The Android network/decoder integration and bounded Java parsers are modifications/additions, not upstream Android code.

## Osmo Client

https://github.com/luisreysan/osmo-client
Reference tree: 96cff353fb2ea582ed2e9835b183a82aeecf430b

MIT License

Copyright (c) 2026 The Osmo Client authors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Prior protocol research acknowledged by upstream: osmosis

https://github.com/KonradIT/osmosis

MIT License

Copyright (c) 2026 Konrad Iturbe

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Prior protocol research acknowledged by upstream: dji-vcam

https://github.com/RB14/dji-vcam

MIT License

Copyright (c) 2026 razboy

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Additional protocol research acknowledged by upstream

OpenPocketCine / OpenCine, Erik Sutton and contributors, https://github.com/erik-sutton95/OpenPocketCine (Apache-2.0). Upstream credits the picture-header description and related Osmo research to this project. No source file from that project is bundled here.

Matis-ard/osmo_nano_webcam, https://github.com/Matis-ard/osmo_nano_webcam, acknowledged by upstream for prior Wi-Fi live-view work. No source file from that project is bundled here.

The GPS/BLE framing uses DJI's published protocol description; see docs/QUELLEN.md. No DJI SDK library binaries are included.

The tiny SPS test fixtures were independently generated with local FFmpeg/libx264/libx265. No FFmpeg or encoder library is redistributed in this project.
