import de.bobrad.sportcam.core.*;
import java.util.*;

public class CoreTests {
 static int assertions=0;
 static void check(boolean value,String name) { assertions++; if(!value) throw new AssertionError(name); }
 static void fails(Runnable r,String name) { boolean failed=false;try{r.run();}catch(IllegalStateException|IllegalArgumentException e){failed=true;}check(failed,name); }
 static byte[] hex(String s) { s=s.replace(" ","");byte[] b=new byte[s.length()/2];for(int i=0;i<b.length;i++)b[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);return b; }
 static EventLedger.Event event(String id,long rev,boolean del,String label){return new EventLedger.Event("match-1",id,rev,del,"goal",label,"LEFT","2026-11-04T12:30:00Z",37000,1);}
 public static void main(String[] args) {
  byte[] official=hex("AA 1B 00 01 00 00 00 00 05 00 57 EE 1D 04 00 00 33 FF 0A 01 47 39 36 F4 FA E1 D0");
  check(DjiProtocol.crc16(official,10)==0xee57,"DJI known CRC16 vector");
  check(DjiProtocol.crc32(official,official.length-4)==0xd0e1faf4L,"DJI known CRC32 vector");
  check(Arrays.equals(DjiProtocol.frame(5,1,0x1d,4,Arrays.copyOfRange(official,14,23)),official),"DJI known complete frame");
  for(int cut=1;cut<official.length;cut++){
   DjiProtocol.Parser p=new DjiProtocol.Parser();
   check(p.feed(Arrays.copyOfRange(official,0,cut)).isEmpty(),"fragment waits "+cut);
   check(p.feed(Arrays.copyOfRange(official,cut,official.length)).size()==1,"fragment reconstructs "+cut);
  }
  DjiProtocol.Parser p=new DjiProtocol.Parser();byte[] both=new byte[54];System.arraycopy(official,0,both,0,27);System.arraycopy(official,0,both,27,27);
  check(p.feed(both).size()==2,"concatenated frames");
  both[17]^=1;check(new DjiProtocol.Parser().feed(both).size()==1,"corrupt CRC32 resync");
  both[10]^=1;check(new DjiProtocol.Parser().feed(both).size()==1,"corrupt header resync");
  check(new DjiProtocol.Parser().feed(new byte[20000]).isEmpty(),"oversize buffer rejected");
  byte[] payload=DjiProtocol.recording(0xff330000L,true);check(DjiProtocol.u32(payload,0)==0xff330000L && payload[4]==0,"use exact camera-provided ID");
  check(DjiProtocol.recording(0xff33,false)[4]==1,"stop is explicit, not a toggle");
  byte[] pair=DjiProtocol.pairing(123,new byte[]{2,3,4,5,6,7},1234,true);
  check(pair.length==33 && pair[26]==1 && DjiProtocol.u16(pair,27)==1234,"pairing payload fields");
  byte[] status=new byte[38];status[0]=1;status[1]=3;status[2]=16;status[3]=3;status[37]=80;DjiProtocol.put16(status,5,65);
  DjiProtocol.Status st=new DjiProtocol.Status(status);check(st.recording() && st.fourK30() && st.recordSeconds==65 && st.battery==80,"camera status");
  fails(()->new DjiProtocol.Status(new byte[10]),"short status rejected");
  MatchClock c=new MatchClock();c.start(1000);check(c.elapsed(46000)==45000,"clock first half");
  c.halftime(46000);check(c.elapsed(900000)==45000,"halftime frozen");c.resume(900000);
  check(c.period()==2 && c.elapsed(910000)==55000,"second half continues no reset");
  c.pause(920000);check(c.elapsed(1000000)==65000,"normal pause frozen");c.resume(1000000);check(c.elapsed(1010000)==75000,"normal resume");
  fails(()->c.halftime(1020000),"second halftime disallowed");
  MatchClock.Snapshot snap=c.snapshot(1010000);MatchClock restored=new MatchClock();restored.restore(snap,1020000,true);
  check(restored.elapsed(1020000)==85000 && restored.running(),"process restart same boot");
  restored.restore(snap,100,false);check(restored.elapsed(10000)==75000 && !restored.running(),"phone reboot freezes clock");
  c.finish(1015000);check(c.elapsed(2000000)==80000,"ended freezes");fails(()->c.resume(2000001),"ended cannot resume");
  check(MatchClock.format(3661000).equals("61:01"),"football minute display");
  EventLedger l=new EventLedger();l.apply("match-1",List.of(event("goal-1",1,false,"Tor")));l.apply("match-1",List.of(event("goal-1",1,false,"Tor")));
  check(l.visible().size()==1,"duplicate event idempotent");l.apply("match-1",List.of(event("goal-1",2,false,"Tor korrigiert")));
  check(l.visible().get(0).label.equals("Tor korrigiert"),"correction revision");l.apply("match-1",List.of(event("goal-1",3,true,"Tor korrigiert")));
  check(l.visible().isEmpty() && l.all().size()==1,"tombstone retained");l.apply("match-1",List.of(event("goal-1",1,false,"Tor")));
  check(l.visible().isEmpty(),"old event cannot revive deletion");
  fails(()->l.apply("match-1",List.of(event("goal-2",1,false,"Neu"),event("goal-1",3,false,"Konflikt"))),"revision conflict rejected");
  check(l.all().size()==1,"batch atomic on failure");
  fails(()->l.apply("match-2",List.of(event("goal-3",1,false,"Falsch"))),"cross-match event rejected");
  l.apply("match-1",List.of());check(l.all().size()==1,"empty delta never deletes events");
  MatchClock firstEnd=new MatchClock();firstEnd.start(1000);firstEnd.finish(4000);
  check(firstEnd.period()==1,"early first-half ending retains period 1");
  MatchClock firstRestored=new MatchClock();firstRestored.restore(firstEnd.snapshot(5000),6000,true);
  check(firstRestored.period()==1 && firstRestored.elapsed(6000)==3000,"ended period survives restoration");
  firstEnd.reset();check(firstEnd.period()==1 && firstEnd.elapsed(9000)==0 && firstEnd.phase()==MatchClock.Phase.READY,"new game explicit reset");
  firstEnd.start(10000);fails(firstEnd::reset,"cannot reset active game");
  l.clear();check(l.all().isEmpty(),"new game clears local remote mirror");
  Random rnd=new Random(4);
  for(int i=0;i<1000;i++){byte[] noise=new byte[rnd.nextInt(1500)];rnd.nextBytes(noise);new DjiProtocol.Parser().feed(noise);}
  check(true,"1000 malformed input buffers processed safely");
  System.out.println("PASS: "+assertions+" assertions; includes 1000 random parser inputs.");
 }
}
