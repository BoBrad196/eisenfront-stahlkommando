#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v java >/dev/null || { echo "JDK 17 oder 21 installieren und JAVA_HOME setzen." >&2; exit 1; }
if [[ -z "${ANDROID_HOME:-}" && ! -f local.properties ]]; then
  echo "Android SDK 35 installieren; ANDROID_HOME setzen oder local.properties anlegen." >&2; exit 1
fi
version=8.9
mkdir -p .tooling
if [[ ! -x ".tooling/gradle-$version/bin/gradle" ]]; then
  command -v curl >/dev/null; command -v unzip >/dev/null
  file=".tooling/gradle-$version-bin.zip"
  curl --fail --location --proto '=https' --tlsv1.2 "https://services.gradle.org/distributions/gradle-$version-bin.zip" -o "$file"
  expected="$(curl --fail --location --proto '=https' --tlsv1.2 "https://services.gradle.org/distributions/gradle-$version-bin.zip.sha256" | tr -d '[:space:]')"
  if command -v sha256sum >/dev/null; then actual="$(sha256sum "$file" | awk '{print $1}')"; else actual="$(shasum -a 256 "$file" | awk '{print $1}')"; fi
  [[ "${#expected}" == 64 && "$expected" == "$actual" ]] || { echo "Gradle-Pruefsumme stimmt NICHT." >&2; exit 1; }
  unzip -q -o "$file" -d .tooling
fi
".tooling/gradle-$version/bin/gradle" --no-daemon :app:assembleDebug "$@"
echo "APK bei erfolgreichem Build: app/build/outputs/apk/debug/app-debug.apk"
