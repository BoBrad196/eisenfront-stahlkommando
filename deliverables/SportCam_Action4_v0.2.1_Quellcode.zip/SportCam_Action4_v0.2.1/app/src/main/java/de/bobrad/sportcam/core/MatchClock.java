package de.bobrad.sportcam.core;

/** Monotonic match clock. Halftime never resets elapsed match time.
 * Caller supplies Android elapsedRealtime(); wall clock is deliberately not used.
 */
public final class MatchClock {
    public enum Phase { READY, FIRST, PAUSED_FIRST, HALFTIME, SECOND, PAUSED_SECOND, ENDED }
    private Phase phase=Phase.READY;
    private int period=1;
    private long accumulated=0,anchor=0;
    public Phase phase() { return phase; }
    public boolean running() { return phase==Phase.FIRST || phase==Phase.SECOND; }
    public int period() { return period; }
    public long elapsed(long now) { return accumulated+(running()?Math.max(0,now-anchor):0); }
    public void start(long now) {
        if(phase!=Phase.READY) throw new IllegalStateException("Spiel wurde bereits gestartet");
        anchor=now; phase=Phase.FIRST;
    }
    private void freeze(long now) { accumulated=elapsed(now); anchor=now; }
    public void pause(long now) {
        if(!running()) throw new IllegalStateException("Spielzeit läuft nicht");
        boolean first=phase==Phase.FIRST; freeze(now); phase=first?Phase.PAUSED_FIRST:Phase.PAUSED_SECOND;
    }
    public void halftime(long now) {
        if(phase!=Phase.FIRST && phase!=Phase.PAUSED_FIRST) throw new IllegalStateException("Halbzeit nur nach erster Hälfte");
        freeze(now); phase=Phase.HALFTIME;
    }
    public void resume(long now) {
        if(phase==Phase.HALFTIME || phase==Phase.PAUSED_SECOND) { phase=Phase.SECOND; period=2; anchor=now; }
        else if(phase==Phase.PAUSED_FIRST) { phase=Phase.FIRST; anchor=now; }
        else throw new IllegalStateException("Keine Pause zum Fortsetzen");
    }
    public void finish(long now) {
        if(phase==Phase.READY || phase==Phase.ENDED) throw new IllegalStateException("Kein laufendes Spiel");
        freeze(now); phase=Phase.ENDED;
    }
    public Snapshot snapshot(long now) { return new Snapshot(phase,elapsed(now),now,period); }
    public void restore(Snapshot s,long now,boolean sameBoot) {
        if(s.phase==null || s.elapsed<0 || s.monotonic<0 || s.period<1 || s.period>2) throw new IllegalArgumentException("Ungültiger Uhrstand");
        phase=s.phase; period=s.period; accumulated=s.elapsed; anchor=now;
        if(running()) {
            if(sameBoot && now>=s.monotonic) accumulated+=now-s.monotonic;
            else phase=phase==Phase.FIRST?Phase.PAUSED_FIRST:Phase.PAUSED_SECOND;
        }
    }
    public void reset() {
        if(phase!=Phase.READY && phase!=Phase.ENDED) throw new IllegalStateException("Laufendes Spiel nicht zurücksetzen");
        phase=Phase.READY;period=1;accumulated=0;anchor=0;
    }
    public static final class Snapshot {
        public final Phase phase; public final long elapsed,monotonic; public final int period;
        public Snapshot(Phase phase,long elapsed,long monotonic,int period) { this.phase=phase;this.elapsed=elapsed;this.monotonic=monotonic;this.period=period; }
    }
    public static String format(long millis) {
        long s=Math.max(0,millis/1000); return String.format(java.util.Locale.ROOT,"%02d:%02d",s/60,s%60);
    }
}
