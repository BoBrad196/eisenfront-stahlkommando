package de.bobrad.sportcam.live;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.view.Surface;
import de.bobrad.sportcam.core.VideoConfig;
import java.nio.ByteBuffer;

/** Called only on the preview worker thread. A displayed-frame callback is NOT a camera REC ACK. */
final class PreviewDecoder implements AutoCloseable {
    interface Listener {void rendered(long count,int width,int height);}
    private final Surface surface;private final Listener listener;
    private final VideoConfig.Collector params=new VideoConfig.Collector();
    private final MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
    private MediaCodec codec;private int width,height;private long shown,lastPts=-1;
    PreviewDecoder(Surface s,Listener l){surface=s;listener=l;}
    void accept(byte[] frame,long timestampNanos) throws Exception {
        VideoConfig config=params.inspect(frame);
        if(config!=null){
            close();width=config.width;height=config.height;
            String mime=config.hevc?"video/hevc":"video/avc";
            codec=MediaCodec.createDecoderByType(mime);
            MediaFormat f=MediaFormat.createVideoFormat(mime,width,height);
            f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE,2*1024*1024);
            f.setByteBuffer("csd-0",ByteBuffer.wrap(config.csd0));
            if(config.csd1!=null)f.setByteBuffer("csd-1",ByteBuffer.wrap(config.csd1));
            codec.configure(f,surface,null,0);codec.start();
        }
        if(codec==null)return;
        drain();int index=codec.dequeueInputBuffer(2000);
        if(index<0)throw new IllegalStateException("Videodecoder überlastet; Vorschau bitte neu verbinden");
        ByteBuffer input=codec.getInputBuffer(index);
        if(input==null||input.capacity()<frame.length)throw new IllegalStateException("Videoframe größer als Decoderpuffer");
        input.clear();input.put(frame);long pts=Math.max(lastPts+1,timestampNanos/1000);lastPts=pts;
        codec.queueInputBuffer(index,0,frame.length,pts,0);drain();
    }
    void drain(){
        if(codec==null)return;
        for(int i=0;i<32;i++){
            int out=codec.dequeueOutputBuffer(info,0);
            if(out>=0){boolean display=info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0;codec.releaseOutputBuffer(out,display);if(display)listener.rendered(++shown,width,height);}
            else if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){MediaFormat f=codec.getOutputFormat();width=f.getInteger(MediaFormat.KEY_WIDTH);height=f.getInteger(MediaFormat.KEY_HEIGHT);}
            else if(out==MediaCodec.INFO_TRY_AGAIN_LATER)break;
        }
    }
    @Override public void close(){MediaCodec old=codec;codec=null;if(old!=null){try{old.stop();}catch(RuntimeException ignored){}old.release();}}
}
