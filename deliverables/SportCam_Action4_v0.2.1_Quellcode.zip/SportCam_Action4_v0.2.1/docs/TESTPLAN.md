# Offene Abnahme – keine bereits bestandenen Gerätetests

## 1. Android-Build

`tools/test-core.sh` und danach `tools/build-android.sh` auf einem Rechner mit SDK 35 ausführen. Erst ein erfolgreicher Gradle-Build mit APK-Datei schließt diesen Punkt. Anschließend Android-Lint und Installation auf dem vorgesehenen Handy prüfen. Berechtigungen ablehnen/wieder erlauben, Prozess beenden, Bildschirm sperren und Zustand wiederherstellen prüfen.

## 2. Eine Action 4, nur Bluetooth

Scan/Kopplung; Start-/Stoppbestätigung getrennt von beobachteter tatsächlicher Aufnahme; aktuelle Statuspakete; Wiederverbinden; kein automatisches Wiederholen eines alten Aufnahmebefehls. 4K/30 auf der Kamera und erzeugter Datei verifizieren.

## 3. WLAN-Vorschau

Richtige/falsche SSID und Passwort; Androids Netzwerkdialog; Kamerabestätigung; Livebild erst nach Decoder-Ausgabe; kein falsches „LIVE“ bei stillstehendem Bild. Verbindungsausfall, WLAN aus/ein, Neuverbinden und Appwechsel prüfen. H.265-Decoder auf dem konkreten Telefon prüfen. Die Vorschau darf Aufnahmeparameter nicht unbemerkt verändern.

## 4. Bluetooth plus WLAN

Während eines echten Livebilds Start/Stopp auslösen; Datei auf SD prüfen. Vorschau trennen und erneut verbinden, ohne die Aufnahme zu stoppen. Prüfen, ob Firmware/Mimo oder die Kamera selbst den Bluetooth-Zugang beim WLAN-Aufbau belegt. Dies ist ein möglicher Hardware-/Firmwarekonflikt und bislang NICHT ausgeschlossen.

## 5. Halbzeit / Pause

Uhr muss in der Pause stehen und danach ohne Reset fortgesetzt werden. Jede Kamera muss ihren Aufnahmestopp bestätigen. Neue Aufnahmeabschnitte, Status-Zeitstempel und tatsächliche Videodateien abgleichen. Unterbrochene Kameraverbindungen und verspätete Statusmeldungen prüfen.

## 6. Zwei Kameras

Nur ein Livebild gleichzeitig; LEFT/RIGHT muss die korrekte echte Kamera zeigen. Alte Rückmeldungen dürfen nicht die neue Seite beschriften. Umschaltzeit messen, auch mit laufender Aufnahme beider Kameras. Internetzugang für Supporter während des Kamera-WLANs separat testen. Nicht vorab als nachgewiesen behandeln.

## 7. Supporter

Aktuelle Komponente wirklich auslesen und API/Anmeldung/Speicherung prüfen. Keine bestehenden Nutzer oder Gerätebindungen verändern. Dann Match-ID, Ereignisrevisionen, Löschungen und verspätete Eingaben integrieren und mit einem separaten Testspiel abnehmen. Server-Halbzeit und Kameraregie dürfen sich nicht gegenseitig mehrfach starten/stoppen. Bis dahin kein produktiver API-Endpunkt und keine automatischen Schreibaktionen.
