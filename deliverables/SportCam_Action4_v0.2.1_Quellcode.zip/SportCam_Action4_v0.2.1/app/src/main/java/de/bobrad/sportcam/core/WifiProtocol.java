package de.bobrad.sportcam.core;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Action-series Wi-Fi DUML/datalink, NOT the separate GPS BLE protocol.
 * Protocol port based on MIT-licensed osmo-client (see THIRD_PARTY_NOTICES.md).
 * No recording/settings commands are exposed here: preview transport only.
 */
public final class WifiProtocol {
    private WifiProtocol() {}
    public static final int APP=2, CAMERA=1, ENCODER=0x48;
    public static final byte[] REGISTER=appRecord(38,11), APP_INFO=appRecord(37,10);
    public static final byte[] ENCODER_REGISTER=hex("170046237c415050000000000002");
    public static final byte[] LIVE_REQUEST=hex("00040200000000000000");
    public static int u16(byte[] b,int at){return (b[at]&255)|((b[at+1]&255)<<8);}
    public static long u32(byte[] b,int at){return (u16(b,at)&0xffffL)|((long)u16(b,at+2)<<16);}
    public static void p16(byte[] b,int at,int v){b[at]=(byte)v;b[at+1]=(byte)(v>>>8);}
    public static byte[] hex(String s){if(s.length()%2!=0)throw new IllegalArgumentException();byte[] b=new byte[s.length()/2];for(int i=0;i<b.length;i++)b[i]=(byte)Integer.parseInt(s.substring(2*i,2*i+2),16);return b;}
    public static int crc8(byte[] data,int offset,int length){int c=0x77;for(int i=offset;i<offset+length;i++){c^=data[i]&255;for(int j=0;j<8;j++)c=(c&1)!=0?(c>>>1)^0x8c:c>>>1;}return c;}
    public static int crc16(byte[] data,int offset,int length){int c=0x3692;for(int i=offset;i<offset+length;i++){c^=data[i]&255;for(int j=0;j<8;j++)c=(c&1)!=0?(c>>>1)^0x8408:c>>>1;}return c;}
    public static final class Message {
        public final int from,to,sequence,flags,set,command;public final byte[] payload;
        public Message(int from,int to,int sequence,int flags,int set,int command,byte[] payload){this.from=from;this.to=to;this.sequence=sequence;this.flags=flags;this.set=set;this.command=command;this.payload=payload.clone();}
        public boolean needsReply(){return (flags&0xc0)==0x40;}
        public byte[] encode(){
            int n=payload.length+13;if(n>1023)throw new IllegalArgumentException("DUML payload too large");
            byte[] b=new byte[n];b[0]=0x55;p16(b,1,n|0x400);b[3]=(byte)crc8(b,0,3);b[4]=(byte)from;b[5]=(byte)to;p16(b,6,sequence);b[8]=(byte)flags;b[9]=(byte)set;b[10]=(byte)command;System.arraycopy(payload,0,b,11,payload.length);p16(b,n-2,crc16(b,0,n-2));return b;
        }
    }
    public static List<Message> messages(byte[] b,int offset,int length){
        List<Message> out=new ArrayList<>();int end=Math.min(b.length,offset+length);
        for(int i=offset;i+13<=end;){
            if((b[i]&255)!=0x55||crc8(b,i,3)!=(b[i+3]&255)){i++;continue;}
            int n=u16(b,i+1)&1023;
            if(n<13||i+n>end||crc16(b,i,n-2)!=u16(b,i+n-2)){i++;continue;}
            out.add(new Message(b[i+4]&255,b[i+5]&255,u16(b,i+6),b[i+8]&255,b[i+9]&255,b[i+10]&255,Arrays.copyOfRange(b,i+11,i+n-2)));i+=n;
        }return out;
    }
    public static byte[] link(int kind,int session,int seq,byte[] body){
        if(body.length+8>0x3fff)throw new IllegalArgumentException("Datalink packet too large");
        byte[] b=new byte[body.length+8];p16(b,0,0x8000|b.length);p16(b,2,session);p16(b,4,seq);b[6]=(byte)kind;for(int i=0;i<7;i++)b[7]^=b[i];System.arraycopy(body,0,b,8,body.length);return b;
    }
    public static boolean validLink(byte[] b){if(b.length<8||(u16(b,0)&0x3fff)!=b.length)return false;int xor=0;for(int i=0;i<8;i++)xor^=b[i]&255;return xor==0&&(b[6]&255)<=5;}
    public static byte[] handshake(int base){
        byte[] b=new byte[40];p16(b,0,base);int at=2;
        for(int[] pair:new int[][]{{100,100},{256,400},{20,100}}){p16(b,at,pair[0]);p16(b,at+2,pair[1]);p16(b,at+4,1472);p16(b,at+6,20);b[at+8]=0;p16(b,at+9,100);at+=11;}
        byte[] tail={1,1,4,1,2};System.arraycopy(tail,0,b,35,5);return b;
    }
    public static byte[] ack(int video,int data,int extra){byte[] b=new byte[26];int i=0;for(int c:new int[]{video,data,extra}){p16(b,i,c);p16(b,i+2,c);i+=8;}return b;}
    public static byte[] routed(int seq,int count,Message m){byte[] raw=m.encode(),b=new byte[12+raw.length];p16(b,0,seq-8);p16(b,2,seq);b[8]=(byte)count;b[9]=1;System.arraycopy(raw,0,b,12,raw.length);return b;}
    public static Message pairing(String identity){
        if(identity.length()!=32||!identity.matches("[a-fA-F0-9]{32}"))throw new IllegalArgumentException("Invalid app identity");
        ByteArrayOutputStream b=new ByteArrayOutputStream();for(String s:new String[]{identity,"osmo"}){byte[] raw=s.getBytes(StandardCharsets.UTF_8);b.write(raw.length);b.write(raw,0,raw.length);}return new Message(APP,7,0x8092,0x40,7,0x45,b.toByteArray());
    }
    private static byte[] appRecord(int gap,int tail){byte[] b=new byte[4+gap+1+8+2+tail];b[1]='A';b[2]='P';b[3]='P';b[4+gap]=2;b[4+gap+9]=2;b[4+gap+10]=8;return b;}
}
