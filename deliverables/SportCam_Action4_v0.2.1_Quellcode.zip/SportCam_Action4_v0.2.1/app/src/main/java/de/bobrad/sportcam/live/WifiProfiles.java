package de.bobrad.sportcam.live;

import android.content.Context;
import android.content.SharedPreferences;
import de.bobrad.sportcam.SecureTokenStore;
import java.util.UUID;

/** Camera WLAN passwords are Keystore-encrypted and excluded from match exports/backups. */
public final class WifiProfiles {
    private final Context context;private final SharedPreferences preferences;
    public WifiProfiles(Context c){context=c.getApplicationContext();preferences=context.getSharedPreferences("preview-wifi",0);}
    private String side(String s){if(!"LEFT".equals(s)&&!"RIGHT".equals(s))throw new IllegalArgumentException("Unbekannte Kameraseite");return s;}
    public String ssid(String s){return preferences.getString(side(s)+".ssid","");}
    public String ip(String s){return preferences.getString(side(s)+".ip","192.168.2.1");}
    public String password(String s) throws Exception {return new SecureTokenStore(context,"wifi."+side(s)).read();}
    public void save(String s,String ssid,String ip,String password) throws Exception {
        side(s);if(ssid.isEmpty()||ssid.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>32)throw new IllegalArgumentException("WLAN-Name fehlt oder ist zu lang");
        if(password.isEmpty()){if(!ssid.equals(ssid(s)))throw new IllegalArgumentException("Für ein anderes Kamera-WLAN das Passwort eingeben");password=password(s);}
        if(password.length()<8||password.length()>63||!password.chars().allMatch(c->c>=32&&c<=126))throw new IllegalArgumentException("WPA2-Passwort: 8–63 ASCII-Zeichen");
        if(!ip.matches("192\\.168\\.\\d{1,3}\\.\\d{1,3}"))throw new IllegalArgumentException("Lokale Kamera-IP 192.168.x.x erforderlich");
        for(String part:ip.split("\\."))if(Integer.parseInt(part)>255)throw new IllegalArgumentException("Ungültige Kamera-IP");
        new SecureTokenStore(context,"wifi."+s).save(password);
        if(!preferences.edit().putString(s+".ssid",ssid).putString(s+".ip",ip).commit())throw new IllegalStateException("WLAN-Profil nicht gespeichert");
    }
    public String identity(){String id=preferences.getString("app-identity","");if(id.length()!=32){id=UUID.randomUUID().toString().replace("-","");preferences.edit().putString("app-identity",id).apply();}return id;}
}
