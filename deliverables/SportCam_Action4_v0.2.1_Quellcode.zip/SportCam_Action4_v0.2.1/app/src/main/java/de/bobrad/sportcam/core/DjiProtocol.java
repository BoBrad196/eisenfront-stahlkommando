package de.bobrad.sportcam.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Independent Java implementation of the published DJI R SDK wire format.
 * References and protocol caveats: docs/QUELLEN.md. No DJI SDK binaries needed.
 */
public final class DjiProtocol {
    private DjiProtocol() {}
    public static final int MIN_FRAME = 18, MAX_FRAME = 1023;
    public static int u8(byte v) { return v & 255; }
    public static int u16(byte[] b, int p) { return u8(b[p]) | (u8(b[p+1]) << 8); }
    public static long u32(byte[] b, int p) {
        return (long)u16(b,p) | ((long)u16(b,p+2) << 16);
    }
    public static void put16(byte[] b, int p, int n) {
        b[p]=(byte)n; b[p+1]=(byte)(n >>> 8);
    }
    public static void put32(byte[] b, int p, long n) {
        put16(b,p,(int)n); put16(b,p+2,(int)(n >>> 16));
    }
    public static int crc16(byte[] b, int count) {
        int crc=0x3aa3;
        for(int i=0;i<count;i++) {
            crc ^= u8(b[i]);
            for(int bit=0;bit<8;bit++) crc=(crc & 1)!=0 ? (crc >>> 1)^0xa001 : crc >>> 1;
        }
        return crc & 65535;
    }
    public static long crc32(byte[] b, int count) {
        int crc=0x3aa3;
        for(int i=0;i<count;i++) {
            crc ^= u8(b[i]);
            for(int bit=0;bit<8;bit++) crc=(crc & 1)!=0 ? (crc >>> 1)^0xedb88320 : crc >>> 1;
        }
        return crc & 0xffffffffL;
    }
    public static byte[] frame(int seq,int type,int set,int id,byte[] payload) {
        if(payload==null || payload.length>MAX_FRAME-MIN_FRAME) throw new IllegalArgumentException("Payload zu lang");
        byte[] b=new byte[MIN_FRAME+payload.length]; b[0]=(byte)0xaa;
        put16(b,1,b.length); b[3]=(byte)type; put16(b,8,seq); put16(b,10,crc16(b,10));
        b[12]=(byte)set; b[13]=(byte)id; System.arraycopy(payload,0,b,14,payload.length);
        put32(b,b.length-4,crc32(b,b.length-4)); return b;
    }
    public static final class Frame {
        public final int seq,type,set,id; public final byte[] payload;
        Frame(byte[] b) { seq=u16(b,8); type=u8(b[3]); set=u8(b[12]); id=u8(b[13]); payload=Arrays.copyOfRange(b,14,b.length-4); }
        public boolean response() { return (type & 32)!=0; }
    }
    /** Handles split and concatenated notifications; verifies both CRCs before dispatch. */
    public static final class Parser {
        private byte[] buffer=new byte[0];
        public void reset() { buffer=new byte[0]; }
        public List<Frame> feed(byte[] input) {
            if(input==null || input.length==0) return new ArrayList<>();
            if(input.length>8192 || buffer.length+input.length>16384) { reset(); return new ArrayList<>(); }
            byte[] all=Arrays.copyOf(buffer,buffer.length+input.length);
            System.arraycopy(input,0,all,buffer.length,input.length);
            List<Frame> out=new ArrayList<>(); int pos=0;
            while(all.length-pos>=12) {
                if(u8(all[pos])!=0xaa) { pos++; continue; }
                byte[] header=Arrays.copyOfRange(all,pos,pos+12);
                int rawLen=u16(header,1),len=rawLen & 1023;
                if((rawLen >>> 10)!=0 || len<MIN_FRAME || header[4]!=0 || crc16(header,10)!=u16(header,10)) { pos++; continue; }
                if(all.length-pos<len) break;
                byte[] frame=Arrays.copyOfRange(all,pos,pos+len);
                if(crc32(frame,len-4)!=u32(frame,len-4)) { pos++; continue; }
                out.add(new Frame(frame)); pos+=len;
            }
            buffer=Arrays.copyOfRange(all,pos,all.length);
            return out;
        }
    }
    public static byte[] pairing(long controllerId,byte[] identity,int code,boolean firstPairing) {
        if(identity.length!=6 || code<0 || code>9999) throw new IllegalArgumentException("Identität/Code ungültig");
        byte[] b=new byte[33]; put32(b,0,controllerId); b[4]=6;
        System.arraycopy(identity,0,b,5,6); b[26]=(byte)(firstPairing?1:0); put16(b,27,code); return b;
    }
    public static byte[] pairingResponse(long controllerId,int slot) {
        byte[] b=new byte[9]; put32(b,0,controllerId); put32(b,5,slot); return b;
    }
    public static byte[] recording(long cameraId,boolean start) {
        byte[] b=new byte[9]; put32(b,0,cameraId); b[4]=(byte)(start?0:1); return b;
    }
    public static byte[] subscribe() { return new byte[]{3,20,0,0,0,0}; }
    public static final class Status {
        public final int mode,state,resolution,fpsIndex,recordSeconds,battery,power,temperature;
        public final long freeMb,remainingSeconds;
        public Status(byte[] b) {
            if(b.length<38) throw new IllegalArgumentException("Statuspaket kürzer als 38 Bytes");
            mode=u8(b[0]); state=u8(b[1]); resolution=u8(b[2]); fpsIndex=u8(b[3]);
            recordSeconds=u16(b,5); freeMb=u32(b,15); remainingSeconds=u32(b,23);
            power=u8(b[28]); temperature=u8(b[30]); battery=u8(b[37]);
        }
        public boolean recording() { return mode==1 && state==3; }
        public boolean videoMode() { return mode==1; }
        public boolean fourK30() { return mode==1 && resolution==16 && fpsIndex==3; }
    }
}
