package de.bobrad.sportcam.core;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/** Strict Action 4 frame assembly. Truncated/late packets are never advertised as a live frame.
 * Unlike a general Osmo client, this receiver requires the Action 4 picture header.
 */
public final class VideoAssembler {
    public interface Sink { void frame(byte[] accessUnit,long firstPacketNanos); }
    private static final int MAX_FRAME=2*1024*1024;
    private final Sink sink;
    private ByteArrayOutputStream frame;
    private int need,lastSequence=-1;
    private long first;
    public long completed,dropped,latePackets;
    public VideoAssembler(Sink sink){this.sink=sink;}
    public void accept(int seq,byte[] data,long now){
        seq&=65535;
        boolean gap=false;
        if(lastSequence>=0){int delta=(seq-lastSequence)&65535;if(delta==0||delta>32768){latePackets++;return;}gap=delta!=8;}
        lastSequence=seq;
        boolean start=data.length>=12&&data[0]==0&&data[1]==0&&data[2]==1&&(data[3]&255)==255;
        if(start){
            if(frame!=null)dropped++;
            frame=null;need=0;
            long total=WifiProtocol.u32(data,4);int header=data[8]&0x3f;
            if(header<12||header>data.length||total<=0||total>MAX_FRAME){dropped++;return;}
            frame=new ByteArrayOutputStream((int)Math.min(total,65536));need=(int)total;first=now;
            append(data,header);
        }else if(frame!=null){
            if(gap){dropped++;frame=null;need=0;return;}
            append(data,0);
        }
    }
    private void append(byte[] b,int offset){int n=Math.min(need,b.length-offset);frame.write(b,offset,n);need-=n;if(need==0){byte[] unit=frame.toByteArray();frame=null;completed++;sink.frame(unit,first);}}
    public void reset(){frame=null;need=0;lastSequence=-1;}
}
