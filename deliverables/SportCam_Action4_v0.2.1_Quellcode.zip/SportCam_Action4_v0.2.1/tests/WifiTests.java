import de.bobrad.sportcam.core.*;
import java.nio.file.*;
import java.util.*;

/** Offline transport/parser tests. Not an Action-4, Android, or camera-firmware integration test. */
public final class WifiTests {
    private static int n;
    private static void ok(boolean b,String s){n++;if(!b)throw new AssertionError(s);}
    private static void rejects(Runnable r,String s){boolean x=false;try{r.run();}catch(IllegalArgumentException e){x=true;}ok(x,s);}
    private static byte[] first(int total,byte[] data,int header){byte[] b=new byte[header+data.length];b[2]=1;b[3]=(byte)255;WifiProtocol.p16(b,4,total);WifiProtocol.p16(b,6,total>>>16);b[8]=(byte)header;System.arraycopy(data,0,b,header,data.length);return b;}
    public static void main(String[] args) throws Exception {
        ok(WifiProtocol.REGISTER.length==64&&WifiProtocol.APP_INFO.length==62,"registration sizes");
        ok(Arrays.equals(WifiProtocol.handshake(0x1238),WifiProtocol.hex("381264006400c005140000640000019001c005140000640014006400c00514000064000101040102")),"handshake independent layout");
        byte[] ack=WifiProtocol.ack(8,16,24);ok(ack.length==26&&WifiProtocol.u16(ack,0)==8&&WifiProtocol.u16(ack,2)==8&&WifiProtocol.u16(ack,8)==16&&WifiProtocol.u16(ack,16)==24,"ack cursors");
        WifiProtocol.Message m=new WifiProtocol.Message(2,1,0x4567,0x40,9,0xa8,WifiProtocol.LIVE_REQUEST);
        byte[] raw=m.encode();ok(raw.length==23&&(WifiProtocol.u16(raw,1)&1023)==23,"DUML frame size");
        var decoded=WifiProtocol.messages(raw,0,raw.length);ok(decoded.size()==1&&decoded.get(0).sequence==0x4567&&decoded.get(0).command==0xa8,"DUML fields");
        ok(decoded.get(0).needsReply(),"DUML request flags");
        byte[] damaged=raw.clone();damaged[12]^=1;ok(WifiProtocol.messages(damaged,0,damaged.length).isEmpty(),"bad payload CRC rejected");
        damaged=raw.clone();damaged[3]^=1;ok(WifiProtocol.messages(damaged,0,damaged.length).isEmpty(),"bad header CRC rejected");
        for(int cut=0;cut<raw.length;cut++)ok(WifiProtocol.messages(Arrays.copyOf(raw,cut),0,cut).isEmpty(),"short message "+cut);
        byte[] noisy=new byte[raw.length+17];System.arraycopy(raw,0,noisy,17,raw.length);ok(WifiProtocol.messages(noisy,0,noisy.length).size()==1,"find DUML inside link routing");
        byte[] link=WifiProtocol.link(5,0x1234,40,WifiProtocol.routed(40,7,m));ok(WifiProtocol.validLink(link),"valid data link");
        ok(WifiProtocol.u16(link,8)==32&&WifiProtocol.u16(link,10)==40&&link[16]==7,"data sequence chain");
        link[7]^=1;ok(!WifiProtocol.validLink(link),"link XOR checked");
        rejects(()->WifiProtocol.link(2,0,0,new byte[16384]),"oversize UDP refused");
        rejects(()->new WifiProtocol.Message(0,0,0,0,0,0,new byte[2000]).encode(),"oversize DUML refused");
        rejects(()->WifiProtocol.pairing("bad"),"invalid identity refused");
        ok(WifiProtocol.pairing("284ae5b8d76b3375a04a6417ad71bea3").payload.length==38,"pairing field size");
        List<byte[]> frames=new ArrayList<>();List<Long> times=new ArrayList<>();VideoAssembler a=new VideoAssembler((b,t)->{frames.add(b);times.add(t);});
        a.accept(0xfff8,first(6,new byte[]{1,2},12),123);
        ok(frames.isEmpty(),"wait for complete frame");
        a.accept(0,new byte[]{3,4,5,6},456);ok(frames.size()==1&&Arrays.equals(frames.get(0),new byte[]{1,2,3,4,5,6}),"sequence wrap and assembly");
        ok(times.get(0)==123,"first packet timestamp retained");
        a.accept(0,new byte[]{3,4,5,6},457);ok(a.latePackets==1&&frames.size()==1,"duplicate ignored");
        a.accept(8,first(6,new byte[]{1},12),500);a.accept(24,new byte[]{2,3,4,5,6},510);ok(frames.size()==1&&a.dropped==1,"lost packet discards incomplete frame");
        a.accept(32,first(3,new byte[]{7,8,9},12),520);ok(frames.size()==2,"resynchronise at next picture");
        a.accept(24,first(2,new byte[]{0,0},12),530);ok(frames.size()==2&&a.latePackets==2,"old packet ignored");
        a.accept(40,first(3_000_000,new byte[]{1},12),540);ok(frames.size()==2,"bounded announced frame size");
        a.accept(48,first(2,new byte[]{5,6},16),550);ok(frames.size()==3,"variable picture header length");
        a.reset();a.accept(0,first(2,new byte[]{0,1},12),600);ok(frames.size()==4,"new session sequence reset");
        byte[] avc=WifiProtocol.hex(Files.readString(Path.of("tests/fixtures/avc-960x540.hex")).trim());
        byte[] hevc=WifiProtocol.hex(Files.readString(Path.of("tests/fixtures/hevc-960x540.hex")).trim());
        VideoConfig.Collector cc=new VideoConfig.Collector();VideoConfig config=cc.inspect(avc);
        ok(config!=null&&!config.hevc&&config.width==960&&config.height==540,"real x264 SPS dimensions including crop");
        ok(config.csd1!=null&&config.csd0.length>4,"AVC CSD buffers");
        ok(cc.inspect(avc)==null,"repeated params do not restart decoder");
        ok(cc.inspect(new byte[]{0,0,1,0x41,1,2})==null,"AVC P slice not HEVC VPS");
        VideoConfig.Collector hc=new VideoConfig.Collector();config=hc.inspect(hevc);
        ok(config!=null&&config.hevc&&config.width==960&&config.height==540,"real x265 SPS dimensions");
        ok(config.csd1==null&&VideoConfig.nals(config.csd0).size()==3,"HEVC VPS SPS PPS CSD");
        ok(hc.inspect(hevc)==null,"repeated HEVC params do not restart decoder");
        VideoConfig.Collector separate=new VideoConfig.Collector();List<byte[]> nals=VideoConfig.nals(hevc);
        ok(separate.inspect(VideoConfig.annex(nals.get(0)))==null,"wait for SPS/PPS");
        ok(separate.inspect(VideoConfig.annex(nals.get(1)))==null,"wait for PPS");
        ok(separate.inspect(VideoConfig.annex(nals.get(2)))!=null,"parameter sets across frames");
        for(int i=0;i<hevc.length;i++)new VideoConfig.Collector().inspect(Arrays.copyOf(hevc,i));
        ok(true,"all truncated HEVC input lengths handled");
        Random random=new Random(1986);
        for(int i=0;i<10000;i++){byte[] b=new byte[random.nextInt(400)];random.nextBytes(b);WifiProtocol.messages(b,0,b.length);WifiProtocol.validLink(b);new VideoConfig.Collector().inspect(b);a.accept((i*8)&65535,b,i);}
        ok(true,"10000 malformed packet inputs bounded");
        System.out.println("PASS: "+n+" Wi-Fi/video assertions; includes 10000 random parser inputs and real x264/x265 SPS fixtures.");
    }
}
