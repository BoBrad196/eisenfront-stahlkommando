package de.bobrad.sportcam;

import android.content.Context;
import android.security.keystore.*;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Bearer token stays out of exports/logs and is encrypted with an Android Keystore key. */
public final class SecureTokenStore {
    private static final String ALIAS="sportcam.supporter.token.v1";
    private final Context context;
    private final String entry;
    public SecureTokenStore(Context c){this(c,"token");}
    public SecureTokenStore(Context c,String name){context=c.getApplicationContext();entry=name;}
    private javax.crypto.SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(!ks.containsAlias(ALIAS)){
            KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            kg.generateKey();
        }
        return (javax.crypto.SecretKey)ks.getKey(ALIAS,null);
    }
    public void save(String token) throws Exception {
        if(token.isEmpty()){context.getSharedPreferences("secure",0).edit().remove(entry).apply();return;}
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
        String value=Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(token.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);
        if(!context.getSharedPreferences("secure",0).edit().putString(entry,value).commit())throw new IllegalStateException("Token konnte nicht gespeichert werden");
    }
    public String read() throws Exception {
        String value=context.getSharedPreferences("secure",0).getString(entry,"");if(value.isEmpty())return "";
        String[] parts=value.split(":",2);if(parts.length!=2)throw new IllegalStateException("Tokenformat ungültig");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));
        return new String(c.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
    }
}
