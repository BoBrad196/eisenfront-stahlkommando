package de.bobrad.sportcam;

import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.content.Context;
import android.os.*;
import java.util.*;
import java.security.SecureRandom;
import de.bobrad.sportcam.core.DjiProtocol;

/** Real BLE transport. Every public method/callback is serialized onto the main looper.
 * No recorded-state claim is inferred from a successful Android write callback.
 * Camera ACK and status telemetry are reported separately.
 * Hardware verification is still required; see docs/TESTPLAN.md.
 */
@SuppressLint("MissingPermission")
public final class DjiBleCamera {
    public interface Listener {
        void changed(DjiBleCamera camera);
        void log(String side,String message);
        void telemetry(DjiBleCamera camera,DjiProtocol.Status status,long receivedMono,long receivedUtc);
    }
    private static UUID uuid(int shortId) { return UUID.fromString(String.format(Locale.ROOT,"0000%04x-0000-1000-8000-00805f9b34fb",shortId)); }
    private static final UUID SERVICE=uuid(0xfff0),NOTIFY=uuid(0xfff4),WRITE=uuid(0xfff5),CCCD=uuid(0x2902);
    // Application-defined controller identity, not a claimed official DJI controller model.
    private static final long CONTROLLER_ID=0x53430001L;
    public final String side;
    public String address="",label="Nicht verbunden",lastCommand="–";
    public boolean authenticated=false,connecting=false;
    public DjiProtocol.Status status;
    public long lastStatusMono=0;
    private final Context context;private final Handler h;private final Listener listener;private final byte[] identity;
    private BluetoothGatt gatt;private BluetoothGattCharacteristic writeChar;
    private final DjiProtocol.Parser parser=new DjiProtocol.Parser();
    private final ArrayDeque<Write> queue=new ArrayDeque<>();
    private Write active;private int mtu=23,seq=1,generation=0;
    private boolean servicesStarted=false,pairingStarted=false,closing=false;
    private long cameraId;private boolean firstPairing;
    private Pending pending;
    private static final class Write {final byte[] bytes;final Runnable done;Write(byte[] b,Runnable d){bytes=b;done=d;}}
    private static final class Pending {final int seq;final boolean target;boolean ack=false;Pending(int s,boolean t){seq=s;target=t;}}
    public DjiBleCamera(Context c,String side,byte[] identity,Listener l) {context=c.getApplicationContext();this.side=side;this.identity=identity.clone();listener=l;h=new Handler(Looper.getMainLooper());}
    public boolean fresh() {return authenticated && status!=null && SystemClock.elapsedRealtime()-lastStatusMono<4000;}
    public boolean commandPending(){return pending!=null;}
    private void notifyChanged(){listener.changed(this);}
    private void info(String s){listener.log(side,s);notifyChanged();}
    public void connect(BluetoothDevice device,boolean first) {
        disconnect();closing=false;firstPairing=first;address=device.getAddress();connecting=true;label="Bluetooth verbindet …";
        mtu=23;servicesStarted=false;pairingStarted=false;cameraId=0;seq=new SecureRandom().nextInt(60000)+1;
        int gen=++generation;
        try {gatt=device.connectGatt(context,false,callback,BluetoothDevice.TRANSPORT_LE);}
        catch(RuntimeException e){fail("Verbindung nicht gestartet: "+e.getClass().getSimpleName());return;}
        h.postDelayed(()->{if(gen==generation && !authenticated) fail("Verbindungs-/Kopplungszeit überschritten");},45000);
        notifyChanged();
    }
    public void disconnect() {
        closing=true;generation++;authenticated=false;connecting=false;status=null;lastStatusMono=0;pending=null;
        queue.clear();active=null;parser.reset();writeChar=null;
        BluetoothGatt old=gatt;gatt=null;
        if(old!=null){try{old.disconnect();old.close();}catch(RuntimeException ignored){}}
        label="Nicht verbunden – Aufnahmestatus unbekannt";notifyChanged();
    }
    private void fail(String message){disconnect();label=message;info(message);}
    private void discover(BluetoothGatt g){if(g!=gatt||servicesStarted)return;servicesStarted=true;if(!g.discoverServices())fail("Dienste konnten nicht abgefragt werden");}
    private final BluetoothGattCallback callback=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int code,int state){h.post(()->{
            if(g!=gatt)return;
            if(code!=BluetoothGatt.GATT_SUCCESS || state==BluetoothProfile.STATE_DISCONNECTED){fail("Bluetooth getrennt ("+code+") – Aufnahme an Kamera prüfen");return;}
            if(state==BluetoothProfile.STATE_CONNECTED){label="Dienste werden gesucht …";notifyChanged();
                if(!g.requestMtu(247))discover(g);else h.postDelayed(()->discover(g),1800);
            }
        });}
        @Override public void onMtuChanged(BluetoothGatt g,int value,int code){h.post(()->{if(g!=gatt)return;if(code==0)mtu=Math.max(23,value);discover(g);});}
        @Override public void onServicesDiscovered(BluetoothGatt g,int code){h.post(()->{
            if(g!=gatt)return;
            BluetoothGattService s=g.getService(SERVICE);
            if(code!=0||s==null){fail("DJI-Dienst FFF0 fehlt");return;}
            BluetoothGattCharacteristic n=s.getCharacteristic(NOTIFY);writeChar=s.getCharacteristic(WRITE);
            if(n==null||writeChar==null){fail("DJI-Schreib-/Statuskanal fehlt");return;}
            if(!g.setCharacteristicNotification(n,true)){fail("Statusmeldungen nicht aktivierbar");return;}
            BluetoothGattDescriptor d=n.getDescriptor(CCCD);if(d==null){fail("Benachrichtigungsdeskriptor fehlt");return;}
            d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            if(!g.writeDescriptor(d))fail("Statusabonnement konnte nicht geschrieben werden");
        });}
        @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int code){h.post(()->{
            if(g!=gatt||!d.getUuid().equals(CCCD))return;
            if(code!=0){fail("Statusabonnement abgelehnt ("+code+")");return;}
            if(!pairingStarted)beginPairing();
        });}
        @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int code){h.post(()->{
            if(g!=gatt||active==null)return;
            if(code!=0){fail("Bluetooth-Schreiben fehlgeschlagen ("+code+")");return;}
            Write sent=active;active=null;if(sent.done!=null)sent.done.run();pump();
        });}
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){
            byte[] value=c.getValue();if(value!=null){byte[] copy=value.clone();h.post(()->receive(g,copy));}
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){
            byte[] copy=value.clone();h.post(()->receive(g,copy));
        }
    };
    private int nextSeq(){seq=(seq+1)&65535;return seq;}
    private void beginPairing(){
        pairingStarted=true;int code=new SecureRandom().nextInt(10000);
        label=String.format(Locale.GERMAN,"An Kamera bestätigen: %04d",code);info("Kopplungsanfrage; Code "+String.format(Locale.ROOT,"%04d",code));
        enqueue(DjiProtocol.frame(nextSeq(),2,0,0x19,DjiProtocol.pairing(CONTROLLER_ID,identity,code,firstPairing)),null);
    }
    private void enqueue(byte[] frame,Runnable done){
        if(gatt==null||writeChar==null){info("Kein Schreibkanal");return;}
        if(queue.size()>100){fail("Bluetooth-Sendepuffer überlastet");return;}
        int chunk=Math.max(20,mtu-3);
        for(int offset=0;offset<frame.length;offset+=chunk){int end=Math.min(frame.length,offset+chunk);queue.add(new Write(Arrays.copyOfRange(frame,offset,end),end==frame.length?done:null));}
        pump();
    }
    private void pump(){
        if(active!=null||queue.isEmpty()||gatt==null||writeChar==null)return;
        active=queue.removeFirst();Write started=active;
        int properties=writeChar.getProperties();
        int type=(properties&BluetoothGattCharacteristic.PROPERTY_WRITE)!=0?BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT:BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;
        writeChar.setWriteType(type);writeChar.setValue(active.bytes);
        if(!gatt.writeCharacteristic(writeChar)){fail("Bluetooth-Schreibauftrag nicht angenommen");return;}
        int gen=generation;
        h.postDelayed(()->{if(gen==generation && active==started)fail("Bluetooth-Schreibbestätigung fehlt");},5000);
    }
    private void receive(BluetoothGatt g,byte[] bytes){
        if(g!=gatt||closing)return;
        for(DjiProtocol.Frame f:parser.feed(bytes)){
            if(f.set==0&&f.id==0x19){
                if(f.response()){
                    if(f.payload.length<5){fail("Ungültige Kopplungsantwort");return;}
                    if(DjiProtocol.u8(f.payload[4])!=0){fail("Kopplung von Kamera abgelehnt");return;}
                }else{
                    if(f.payload.length<29 || f.payload[26]!=2){info("Unerwartete Kopplungsdaten; kein Verbindungs-Erfolg");continue;}
                    if(DjiProtocol.u16(f.payload,27)!=0){fail("Kopplung am Kameradisplay abgelehnt");return;}
                    cameraId=DjiProtocol.u32(f.payload,0);
                    int index=side.equals("LEFT")?1:2;
                    enqueue(DjiProtocol.frame(f.seq,32,0,0x19,DjiProtocol.pairingResponse(CONTROLLER_ID,index)),()->{
                        authenticated=true;connecting=false;label="Verbunden – warte auf Kamerastatus";info("Kopplung bestätigt; Kamera-ID 0x"+Long.toHexString(cameraId));
                        enqueue(DjiProtocol.frame(nextSeq(),0,0x1d,5,DjiProtocol.subscribe()),null);
                    });
                }
            }else if(authenticated&&f.set==0x1d&&f.id==2&&!f.response()){
                try{
                    status=new DjiProtocol.Status(f.payload);lastStatusMono=SystemClock.elapsedRealtime();
                    label=status.recording()?"REC – durch Kamerastatus bestätigt":"Verbunden – keine Videoaufnahme";
                    if(status.power==3)label="Kamera im Ruhemodus";
                    if(status.temperature>=2)label="Überhitzung – Kamera prüfen";
                    if(pending!=null && pending.ack && status.videoMode() && status.recording()==pending.target){
                        lastCommand=(pending.target?"START":"STOP")+" durch Kamerastatus bestätigt";pending=null;info(lastCommand);
                    }
                    listener.telemetry(this,status,lastStatusMono,System.currentTimeMillis());notifyChanged();
                }catch(IllegalArgumentException e){info("Unvollständige Statusmeldung ignoriert");}
            }else if(authenticated&&f.set==0x1d&&f.id==3&&f.response()&&pending!=null&&f.seq==pending.seq){
                if(f.payload.length<1){info("Leeres Befehls-ACK ignoriert");continue;}
                int result=DjiProtocol.u8(f.payload[0]);
                if(result!=0){lastCommand="Kamera lehnt Befehl ab ("+result+")";pending=null;info(lastCommand);}
                else{pending.ack=true;lastCommand="Befehl angenommen – warte auf Aufnahmestatus";info(lastCommand);}
            }
        }
    }
    /** Never retries an uncertain command; a manual retry sends an explicit target state. */
    public boolean setRecording(boolean start){
        if(!authenticated){lastCommand="Nicht gesendet: Kamera nicht verbunden";info(lastCommand);return false;}
        if(start && !fresh()){lastCommand="Nicht gesendet: kein aktueller Kamerastatus";info(lastCommand);return false;}
        boolean overridingStart=pending!=null && pending.target && !start;
        if(pending!=null){
            if(!start && pending.target){info("STOP hat Vorrang vor noch offenem START");pending=null;}
            else{lastCommand="Vorheriger Befehl noch offen";info(lastCommand);return false;}
        }
        if(start && (!status.videoMode() || !status.fourK30())){lastCommand="An Kamera zuerst VIDEO / 4K / 30 einstellen";info(lastCommand);return false;}
        if(!overridingStart && fresh() && status.recording()==start){lastCommand=start?"Kamera nimmt bereits auf":"Kamera ist bereits gestoppt";info(lastCommand);return true;}
        if(start && (status.power==3||status.temperature>=2||status.freeMb==0)){lastCommand="Start gesperrt: Strom-/Temperatur-/SD-Status prüfen";info(lastCommand);return false;}
        Pending command=new Pending(nextSeq(),start);pending=command;lastCommand=(start?"START":"STOP")+" gesendet – noch unbestätigt";info(lastCommand);
        enqueue(DjiProtocol.frame(command.seq,2,0x1d,3,DjiProtocol.recording(cameraId,start)),null);
        h.postDelayed(()->{if(pending==command){lastCommand="ZEITÜBERSCHREITUNG: "+(start?"START":"STOP")+" nicht bestätigt – Kamera prüfen";pending=null;info(lastCommand);}},7000);
        return true;
    }
}
