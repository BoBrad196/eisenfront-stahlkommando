# Prüfbericht 0.2-dev – 4. November 2026

## Durchgeführt

Der Java-Programmkern wurde mit `javac --release 17` kompiliert und ausgeführt. Das ist eine echte JVM-Prüfung der unabhängigen Kernklassen, nicht der gesamten Android-App.

| Prüfung | Ergebnis |
|---|---|
| Bestehende Kernprüfungen (BLE-Rahmen, Uhr/Halbzeit, Ereignisrevisionen) | 89 Assertions erfolgreich |
| Neue WLAN-/Video-Prüfungen | 61 Assertions erfolgreich |
| Zufalls-Eingabepuffer | 1.000 bestehende und 10.000 zusätzliche ohne Testabbruch |
| DUML-/Datalink-Rahmen | Längen, Prüfsummen, Routing, Bestätigungscursor und ungültige Eingaben geprüft |
| Action-4-Frame-Zusammensetzung | Aufteilung, Sequenzüberlauf, Paketverlust, Duplikate, verspätete Pakete, Größenlimit und Wiederaufnahme am nächsten Bild geprüft |
| H.264-/H.265-Parameter | SPS-Maße 960×540 einschließlich Crop aus unabhängig erzeugten x264/x265-Testdaten erkannt |
| Java-Grammatik | Alle 15 App-Java-Dateien geparst |

Die unabhängigen Codec-Testdaten wurden lokal mit FFmpeg/libx264/libx265 aus einem synthetischen einfarbigen Bild erzeugt. Im Projekt liegen nur ihre kleinen Parameterdatensätze. Es werden keine FFmpeg-Binärdateien mitgeliefert.

## Nicht durchgeführt

* Keine Gradle-Kompilierung der Android-App, keine Android-Lint-Prüfung und kein DEX/APK-Paket.
* Kein Start auf einem Emulator oder Handy, keine Android-MediaCodec-Ausgabeprüfung.
* Keine DJI-Kopplung, kein 4K-Aufnahmetest, keine gleichzeitige Bluetooth-/WLAN-Prüfung.
* Keine Prüfung an zwei Action 4, kein Reichweiten-/Dauer-/Wärmetest.
* Kein authentifizierter Supporter-Ereignisabruf und kein Abgleich mit aktuellem Joomla-Quellcode.

## Build-Hindernis – konkret geprüft

Java ist installiert, Android-SDK/Gradle sind nicht eingerichtet. Eine lokale Suche nach Android-Plattform-JAR und Build-Binaries war ohne Ergebnis. Der direkte GitHub-Downloadversuch scheiterte mit `Could not resolve host: github.com`; auch der separate SDK-Download konnte nicht bezogen werden. Es wird deshalb KEINE erfolgreiche APK-Erstellung behauptet.

## Websiteprüfung

Die bekannten öffentlichen Supporter- und Manifestadressen wurden erneut lesend aufgerufen. Es kam kein auswertbarer geschützter API-/Komponentenquellcode zurück. Der sichtbare Supporter-Seitentitel ersetzt keinen API-Nachweis und keine Authentifizierungsprüfung. Es wurde nichts auf tsvkirberg.de installiert, hochgeladen oder geändert.

Das zugängliche GitHub-Repository war Eisenfront, nicht SportCam/FootballSeason. Es wurde nicht für dieses andere Projekt verändert oder als Build-Umgebung verwendet.

## Bewertung

**Quellcodefortschritt mit bestandenen Offline-Kerntests. Nicht als fertige App oder einsatzfähige Fußballkamera-Lösung freigegeben.**
