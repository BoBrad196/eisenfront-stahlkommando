# Supporter-Anbindung — ENTWURF, nicht vorhandene Serverfunktion

## Status

Keine bestehende Route wurde nachgewiesen. Kein Serveradapter, Joomla-Plugin oder Joomla-Installationspaket ist enthalten. Der Endpoint in der Android-App bleibt standardmäßig leer. Die öffentliche Supporter-Anmeldeseite ist keine JSON-API und darf nicht als API-Endpoint eingetragen werden.

Dieser Vertrag ist ein Vorschlag für die spätere Anpassung an den vorhandenen FootballSeason-Code. Vorhandene Benutzerkonten, Gerätebindung und Rechte dürfen nicht durch einen globalen Admin-Token ersetzt werden. Es wird ausschließlich gelesen; Änderungen an Toren, Ergebnissen, Halbzeit und Spielern bleiben in der bestehenden Supporter-App.

## Vorgeschlagener Lesevertrag

Ein authentifizierter HTTPS-GET auf einen **noch zu bestimmenden** Endpoint erhält `match_id` und `cursor` als URL-Parameter. Der Token wird ausschließlich im HTTP-Header `Authorization: Bearer …` übertragen. Der Endpoint muss auf `tsvkirberg.de` oder `www.tsvkirberg.de` liegen. Weiterleitungen werden vom Client abgelehnt, damit Token nicht unbemerkt weitergereicht werden.

HTTP 200 muss `Content-Type: application/json` und das unten gezeigte Format liefern. Jeder Datensatz, auch eine Löschmarkierung, enthält alle Pflichtfelder. Das erleichtert die gleichartige Prüfung und Speicherung. `next_cursor` ist eine opaque Zeichenkette und wird erst nach einem vollständig erfolgreichen Batch gespeichert. Ein unveränderter Stand darf ein leeres Array und den bisherigen Cursor liefern. Das Client-Update erfolgt manuell per „Ereignisse lesen“; kein automatischer Polling-Dienst ist implementiert.

```json
{
  "schema": "sportcam.supporter.events.v1",
  "match_id": "BEISPIEL-NICHT-ECHTES-SPIEL",
  "next_cursor": "revision-17",
  "events": [
    {
      "id": "example-goal-1",
      "revision": 1,
      "deleted": false,
      "type": "goal",
      "label": "Beispieltor – keine echten Spieldaten",
      "side": "UNKNOWN",
      "occurred_at": "2026-11-04T15:32:10Z",
      "match_elapsed_ms": 1930000,
      "period": 1
    }
  ]
}
```

`match_elapsed_ms` ist die kumulierte Spielzeit OHNE Pausen. `period` ist 1 oder 2. `occurred_at` sollte die tatsächliche Ereigniszeit und nicht bloß die spätere Eingabezeit sein. Kann der Server diese nicht liefern, muss das Datenmodell angepasst und die Unsicherheit ausgewiesen werden; keine fiktiv präzisen Werte erzeugen. `side` ist LEFT, RIGHT, BOTH oder UNKNOWN. Aus der Mannschaftsseite folgt nicht automatisch die Kamera, da sich die Spielrichtung ändern kann.

## Änderungsregeln

Die Ereignis-ID bleibt bei einer Korrektur gleich. Jede inhaltliche Änderung erhält eine höhere positive Revision. Die Kombination gleicher ID und gleicher Revision muss inhaltlich identisch sein. Andernfalls verwirft der Client den gesamten Batch. Eine Löschung wird mit `deleted=true` und höherer Revision geliefert; ihr Datensatz bleibt als Tombstone erhalten. Das Fehlen eines Ereignisses in einem Delta ist keine Löschung.

Die Serverimplementierung muss den Zugriff pro Spiel und Benutzer prüfen und stabile Cursor/Paginierung definieren. Die aktuelle Clientfassung liest pro Knopfdruck eine Antwort bis zwei MB und höchstens 10.000 Einträge; ein weiterer Cursor wird erst beim nächsten Abruf benutzt. Vollständige Wiederaufnahme nach abgelaufenem Cursor ist noch abzustimmen. Vor einer Produktivfreigabe fehlen insbesondere Server-Integrationstests, Token-Erneuerung/-Widerruf, Offline-Abgleich und eine passende Gerätefreigabe.

## Spielzeit- und Kamerakopplung

Ein importiertes Tor erscheint vorerst nur in der lokalen Ereignisliste. Es startet keine Kamera und erzeugt noch keine präzise MP4-Zuordnung. Die beiden Apps synchronisieren derzeit weder die Halbzeit noch die Spieluhr. Vor der Umsetzung muss geklärt werden, welche Instanz den verbindlichen Spielstatus führt. Empfohlenes Ziel: Supporter verwaltet den Spielstatus; SportCam speichert Kamera-Befehle und deren tatsächliche Rückmeldungen getrennt.

Die spätere Videoanbindung benötigt mindestens stabile Aufnahmeabschnitt-IDs je Kamera, Dateisplit-Zuordnung, eine kalibrierte Zeitbasis zwischen Handy/Server/Kamera, Revisionsverarbeitung und einen manuellen Korrekturweg für verspätet eingetragene Ereignisse. Allein eine Spielminute oder ein Server-Eingabezeitstempel reicht nicht.

FootballSeason und Alte Herren erhalten getrennte Datenbereiche und Berechtigungen. In diesem Stand ist ausschließlich FootballSeason als zukünftiges Ziel beschrieben, nicht `com_bobrad_alteherren`.
