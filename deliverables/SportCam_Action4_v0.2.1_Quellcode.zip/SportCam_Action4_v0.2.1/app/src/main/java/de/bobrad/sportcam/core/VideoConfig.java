package de.bobrad.sportcam.core;

import java.io.ByteArrayOutputStream;
import java.util.*;

/** Bounded Annex-B parsing and H.264/H.265 SPS dimensions for Android MediaCodec. */
public final class VideoConfig {
    public final boolean hevc;public final int width,height;public final byte[] csd0,csd1;
    private VideoConfig(boolean hevc,int w,int h,byte[] a,byte[] b){this.hevc=hevc;width=w;height=h;csd0=a;csd1=b;}
    public static List<byte[]> nals(byte[] b){
        List<byte[]> out=new ArrayList<>();int start=-1,i=0;
        while(i+2<b.length){int n=b[i]==0&&b[i+1]==0?(b[i+2]==1?3:(i+3<b.length&&b[i+2]==0&&b[i+3]==1?4:0)):0;
            if(n>0){if(start>=0&&i>start)out.add(Arrays.copyOfRange(b,start,i));start=i+n;i+=n;}else i++;}
        if(start>=0&&start<b.length)out.add(Arrays.copyOfRange(b,start,b.length));return out;
    }
    public static byte[] annex(byte[] n){byte[] b=new byte[n.length+4];b[3]=1;System.arraycopy(n,0,b,4,n.length);return b;}
    public static final class Collector {
        private final Map<Integer,byte[]> h265=new HashMap<>(),h264=new HashMap<>();
        private boolean seenHevc=false;private byte[] fingerprint;
        public VideoConfig inspect(byte[] b){
            for(byte[] n:nals(b)){if(n.length<2)continue;int a=n[0]&31,h=(n[0]>>1)&63;
                if(h>=32&&h<=34&&(n[0]&1)==0&&(n[1]&0xf8)==0&&(n[1]&7)!=0){seenHevc=true;h265.put(h,n);}
                if(a==7||a==8)h264.put(a,n);
            }
            try {
                if(seenHevc&&h265.size()==3){byte[] s=h265.get(33);int[] d=hevcSize(s);byte[] all=concat(annex(h265.get(32)),annex(s),annex(h265.get(34)));if(Arrays.equals(fingerprint,all))return null;fingerprint=all;return new VideoConfig(true,d[0],d[1],all,null);}
                if(!seenHevc&&h264.size()==2){byte[] s=h264.get(7);int[] d=avcSize(s);byte[] a=annex(s),p=annex(h264.get(8)),fp=concat(a,p);if(Arrays.equals(fingerprint,fp))return null;fingerprint=fp;return new VideoConfig(false,d[0],d[1],a,p);}
            }catch(IllegalArgumentException invalid){/* Wait for a valid, complete parameter set. */}
            return null;
        }
    }
    private static byte[] concat(byte[]...arr){ByteArrayOutputStream out=new ByteArrayOutputStream();for(byte[] b:arr)out.write(b,0,b.length);return out.toByteArray();}
    private static final class Bits {
        final byte[] b;int p=0;
        Bits(byte[] nal,int header){ByteArrayOutputStream out=new ByteArrayOutputStream();int zeros=0;for(int i=header;i<nal.length;i++){int v=nal[i]&255;if(zeros>=2&&v==3){zeros=0;continue;}out.write(v);zeros=v==0?zeros+1:0;}b=out.toByteArray();}
        int read(int n){if(n<0||n>31||p+n>b.length*8)throw new IllegalArgumentException("Truncated SPS");int v=0;while(n-->0){v=(v<<1)|((b[p>>>3]>>(7-(p&7)))&1);p++;}return v;}
        void skip(int n){if(n<0||p+n>b.length*8)throw new IllegalArgumentException("Truncated SPS");p+=n;}
        int ue(){int zeros=0;while(read(1)==0)if(++zeros>24)throw new IllegalArgumentException("Invalid SPS value");return ((1<<zeros)-1)+read(zeros);}
        int se(){int n=ue();return (n&1)==1?(n+1)/2:-n/2;}
    }
    private static int[] checked(int w,int h){if(w<16||h<16||w>8192||h>8192)throw new IllegalArgumentException("Invalid video dimensions");return new int[]{w,h};}
    public static int[] hevcSize(byte[] sps){
        Bits b=new Bits(sps,2);b.skip(4);int layers=b.read(3);b.skip(1);b.skip(96);
        int[] profile=new int[layers],level=new int[layers];for(int i=0;i<layers;i++){profile[i]=b.read(1);level[i]=b.read(1);}if(layers>0)b.skip((8-layers)*2);
        for(int i=0;i<layers;i++){if(profile[i]!=0)b.skip(88);if(level[i]!=0)b.skip(8);}
        b.ue();int chroma=b.ue();if(chroma>3)throw new IllegalArgumentException();boolean separate=chroma==3&&b.read(1)==1;
        int w=b.ue(),h=b.ue();if(b.read(1)!=0){int l=b.ue(),r=b.ue(),t=b.ue(),bot=b.ue();int c=separate?0:chroma;w-=(c==1||c==2?2:1)*(l+r);h-=(c==1?2:1)*(t+bot);}return checked(w,h);
    }
    public static int[] avcSize(byte[] sps){
        Bits b=new Bits(sps,1);int profile=b.read(8);b.skip(16);b.ue();int chroma=1;boolean separate=false;
        if(Arrays.asList(100,110,122,244,44,83,86,118,128,138,139,134,135).contains(profile)){
            chroma=b.ue();if(chroma>3)throw new IllegalArgumentException();if(chroma==3)separate=b.read(1)==1;
            b.ue();b.ue();b.skip(1);if(b.read(1)!=0){int count=chroma==3?12:8;for(int i=0;i<count;i++)if(b.read(1)!=0){int last=8,next=8;for(int j=0;j<(i<6?16:64);j++){if(next!=0)next=(last+b.se()+256)%256;last=next==0?last:next;}}}
        }
        b.ue();int poc=b.ue();if(poc==0)b.ue();else if(poc==1){b.skip(1);b.se();b.se();int n=b.ue();if(n>255)throw new IllegalArgumentException();for(int i=0;i<n;i++)b.se();}else if(poc>2)throw new IllegalArgumentException();
        b.ue();b.skip(1);int w=(b.ue()+1)*16,hUnits=b.ue()+1;int frame=b.read(1);if(frame==0)b.skip(1);b.skip(1);int h=hUnits*16*(2-frame);
        if(b.read(1)!=0){int l=b.ue(),r=b.ue(),t=b.ue(),bot=b.ue();int c=separate?0:chroma;int x=c==1||c==2?2:1,y=(c==1?2:1)*(2-frame);w-=x*(l+r);h-=y*(t+bot);}return checked(w,h);
    }
}
