# SportCam Action 4 – 0.2-dev

**Dies ist ein erweitertes Android-Quellcodeprojekt, keine fertige oder hardwaregeprüfte App. Eine APK liegt NICHT bei.**

## Tatsächlicher Lieferumfang

Der vorhandene Stand 0.1 wurde erweitert, nicht durch ein anderes Projekt ersetzt. Die Bluetooth-Kamerasteuerung, Spieluhr, Halbzeitpause, lokale Markerspeicherung und JSON-Exporte bleiben erhalten. Die vollständige App ist weiterhin nicht mit dem Android-SDK kompiliert und nicht an einer echten Kamera getestet.

Neu programmiert:

* Native WLAN-Livebildanbindung für die Action-4-Protokollvariante: TCP-Kopplungsimpuls, UDP-Datalink, Registrierung, Heartbeats, Bestätigungen, Antwort auf Kameraanfragen und begrenzte Wiederholungen verlorener Steuerpakete.
* H.264/H.265-Frame-Zusammensetzung und Android-MediaCodec-Ausgabe in eine echte Videofläche. Keine Beispielbilder, keine simulierte „LIVE“-Meldung. Die Live-Anzeige setzt Decoder-Ausgabe voraus.
* LEFT/RIGHT wählt genau eine Vorschau. Der Wechsel beendet die bisherige WLAN-Sitzung. Alte Netzwerk-Rückmeldungen können nicht die neu ausgewählte Kamera als verbunden anzeigen.
* WLAN-Profile pro Kameraseite. Passwörter werden mit Android Keystore verschlüsselt und nicht in Spielprotokolle exportiert.
* Kennzeichnung eines eingefrorenen/ausgefallenen Livebilds. „LIVE trennen“ sendet keinen Kamera-Aufnahmestopp.
* Die Kamera-Sockets werden einzeln an ihr WLAN gebunden. Der App-Prozess wird nicht insgesamt auf das internetlose Kamera-WLAN umgeleitet. Ob Mobilfunk parallel verfügbar bleibt, hängt weiterhin von Telefon, Android und Verbindungssituation ab.
* Vorbereiteter, manuell auslösbarer GitHub-Actions-Build. Dieser Workflow ist nur eine Datei im ZIP; er wurde nicht in ein Repository hochgeladen und nicht ausgeführt.

## Nicht erledigt / nicht nachgewiesen

1. **Keine APK und kein vollständiger Android-Build.** Im Bearbeitungssystem fehlt das Android-SDK. Der Versuch, Build-Werkzeuge herunterzuladen, war nicht erfolgreich; direkte Netzwerkaufrufe scheiterten an der Namensauflösung. Die Java-Syntaxprüfung ersetzt keine Android-Typprüfung.
2. **Kein Action-4-Hardwaretest.** WLAN-Kopplung, Decoderbetrieb, Aufnahme und Vorschau gleichzeitig, die tatsächliche WLAN-Umschaltzeit und die Koexistenz mit unserer Bluetooth-Verbindung sind offen.
3. **Keine aktive Supporter-Anbindung.** Es gibt weiterhin nur einen Entwurfsadapter. Der tatsächliche geschützte API-Endpunkt, sein Authentifizierungsverfahren und der aktuelle Komponentenquellcode fehlen. Die öffentlichen Seitenaufrufe bestätigen keine nutzbare Ereignis-API. Keine Joomla-Datei, Anmeldung, Gerätebindung oder Ereignisdatenbank wurde verändert.
4. **Keine automatische Halbzeit-Synchronisation mit Supporter.** Die Halbzeitsteuerung ist lokal programmiert: Uhr anhalten ohne Zurücksetzen, Stopp an verbundene Kameras, neue Aufnahmen beim Fortsetzen. Remote-Änderungen sind nicht angebunden.
5. **Keine fertige Highlight-Erstellung, kein Video-Stitching und keine bildgenaue Synchronisation.** Kamerastatus-Zeitstempel und lokale Marker sind noch keine verifizierte Zuordnung zu allen tatsächlich erzeugten Videodateien.

## Prüfergebnis

`bash tools/test-core.sh`

* 89 bestehende Kernprüfungen erfolgreich.
* 61 zusätzliche WLAN-/Video-Prüfungen erfolgreich.
* Insgesamt 11.000 zufällige Eingabepuffer ohne Testabbruch verarbeitet. Das ist ein kleiner Robustheitstest, kein umfassendes Security-Audit.
* H.264-/H.265-SPS-Parser mit unabhängig erzeugten x264/x265-Parameterdaten für 960 × 540 geprüft, einschließlich Bildbeschnitt. Diese Daten stammen nicht von einer DJI-Kamera.
* Java-Grammatik aller 15 App-Quelldateien geprüft.
* Keine Android-Installation, kein Emulatorstart, kein echter Decoderlauf auf Android, keine Kameraverbindung.

Rohprotokoll: `docs/TESTAUSGABE.txt`. Details: `docs/TESTBERICHT.md`.

## Bauen – nur auf einem System mit Android-SDK

Voraussetzungen: JDK 17 oder 21, Android SDK Platform 35, übliche Android-Build-Tools und Internetzugriff zum Laden der Gradle-/Google-Maven-Abhängigkeiten. `ANDROID_HOME` setzen oder in `local.properties` einen gültigen `sdk.dir` eintragen.

Linux/macOS:

```sh
bash tools/test-core.sh
bash tools/build-android.sh
```

Windows PowerShell:

```powershell
.\tools\test-core.ps1
.\tools\build-android.ps1
```

Die Build-Skripte laden Gradle 8.9 über die offizielle Quelle und kontrollieren die veröffentlichte SHA-256-Prüfsumme. **Erst bei erfolgreichem Android-Build** entsteht `app/build/outputs/apk/debug/app-debug.apk`. Eine erzeugte Debug-APK ist noch keine für Spiele freigegebene Version.

Alternativ kann der enthaltene manuelle Workflow in einem **eigenen separaten Repository** laufen, nachdem der Projektinhalt dort hochgeladen wurde. Er wurde in dieser Bearbeitung nicht ausgeführt. Das bestehende Eisenfront-Repository wurde nicht verändert. Keine bezahlten Build-Dienste wurden gestartet.

## Vorgesehener erster Gerätetest nach erfolgreichem Build

Kamera zunächst ohne wichtiges Spiel testen. Die endgültige Aufnahme muss immer am Kameradisplay/auf der SD-Karte geprüft werden; App-Anzeige allein ist kein Beweis für eine laufende Aufnahme.

1. Eine vorhandene Action 4 auf 4K/30 einstellen. Speicherkarte, Akku und Firmware notieren. DJI Mimo schließen.
2. In SportCam Bluetooth freigeben, Kamera suchen und LEFT zuordnen. Kopplung am Kameradisplay bestätigen. Aufnahme beginnen und stoppen; Status und Datei auf der Karte prüfen.
3. „WLAN der ausgewählten Kamera einrichten“: tatsächlichen WLAN-Namen und das Passwort der Kamera eingeben. Standard-IP im Profil ist 192.168.2.1. Gegebenenfalls Kamera-WLAN über ihre Einstellungen aktivieren. Eine gegebenenfalls vorausgesetzte frühere Mimo-Aktivierung wird hier nicht ersetzt.
4. „LIVE verbinden“ drücken. Androids Netzwerkfreigabe und gegebenenfalls die Kopplung am Kameradisplay bestätigen. Ein Fehler bleibt sichtbar, statt ein Beispielbild zu zeigen.
5. Erst bei einem echten Livebild getrennt testen: Aufnahme plus Vorschau, Vorschau trennen während Aufnahme, Halbzeitpause und Fortsetzen. Das Öffnen einer anderen App beendet die Vorschau; die Kamerasteuerung liegt separat im Dienst.
6. Die zweite Kamera erst später prüfen. WLAN-Wechsel ist keine sofortige Videoschnitt-Umschaltung; Android darf eine Bestätigung verlangen und der Stream muss neu aufgebaut werden.

Die Supporter-App bleibt die zentrale Ereignisverwaltung. Die lokalen TOR-/CHANCE-/FOUL-Schaltflächen sind ausschließlich Videomarker, keine zweite Ergebnisverwaltung und kein Ersatz für die echte Schnittstelle.

## Dateien

* `app/src/main/java/de/bobrad/sportcam/live/`: Android-WLAN-Verbindung und Decoder.
* `core/WifiProtocol.java`, `core/VideoAssembler.java`, `core/VideoConfig.java`: unabhängig testbare Protokoll-/Videoverarbeitung.
* `docs/SUPPORTER_API_ENTWURF.md`: unverändert ein Entwurf, kein existierender API-Nachweis.
* `docs/TESTPLAN.md`: offene Abnahmeschritte.
* `THIRD_PARTY_NOTICES.md`, `docs/QUELLEN.md`: Protokollquellen und Lizenzhinweise.

Die alte Version 0.1 bleibt als eigenständiges ZIP unverändert erhalten.
