package de.bobrad.sportcam;

import de.bobrad.sportcam.core.EventLedger;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Proposed read-only adapter. NOT a claim that this API exists on tsvkirberg.de.
 * Endpoint must be confirmed from the real Joomla source before use.
 * Never submits events, halftime or camera commands to FootballSeason.
 */
public final class SupporterReader {
    public static final String SCHEMA="sportcam.supporter.events.v1";
    public static final class Batch {
        public final List<EventLedger.Event> events; public final String cursor;
        Batch(List<EventLedger.Event> e,String c){events=e;cursor=c;}
    }
    public static URI validateEndpoint(String value) throws Exception {
        URI uri=new URI(value);
        if(!"https".equalsIgnoreCase(uri.getScheme()) || uri.getUserInfo()!=null || uri.getFragment()!=null
            || (uri.getPort()!=-1 && uri.getPort()!=443)
            || !("www.tsvkirberg.de".equalsIgnoreCase(uri.getHost()) || "tsvkirberg.de".equalsIgnoreCase(uri.getHost())))
            throw new IllegalArgumentException("Nur HTTPS-Endpunkte auf tsvkirberg.de sind zugelassen");
        return uri;
    }
    public static Batch read(String endpoint,String token,String matchId,String cursor) throws Exception {
        URI checked=validateEndpoint(endpoint);
        if(token.isEmpty() || token.contains("\r") || token.contains("\n"))throw new IllegalArgumentException("Gültiger API-Token fehlt");
        String join=checked.getRawQuery()==null?"?":"&";
        URL url=new URL(checked+join+"match_id="+URLEncoder.encode(matchId,"UTF-8")+"&cursor="+URLEncoder.encode(cursor,"UTF-8"));
        HttpURLConnection con=(HttpURLConnection)url.openConnection();
        con.setConnectTimeout(10000);con.setReadTimeout(15000);con.setInstanceFollowRedirects(false);
        con.setRequestProperty("Authorization","Bearer "+token);con.setRequestProperty("Accept","application/json");
        try {
            int status=con.getResponseCode();
            if(status!=200)throw new IOException("Supporter-API meldet HTTP "+status+". Keine Daten geändert.");
            String mime=con.getContentType();if(mime==null||!mime.toLowerCase(Locale.ROOT).contains("application/json"))throw new IOException("Keine JSON-API-Antwort; möglicherweise Anmeldeseite");
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            try(InputStream in=con.getInputStream()){
                byte[] buffer=new byte[8192];int read;
                while((read=in.read(buffer))!=-1){if(out.size()+read>2_000_000)throw new IOException("Antwort zu groß");out.write(buffer,0,read);}
            }
            return parse(new JSONObject(out.toString(StandardCharsets.UTF_8.name())),matchId);
        } finally {con.disconnect();}
    }
    public static Batch parse(JSONObject json,String matchId) throws Exception {
        if(!SCHEMA.equals(json.getString("schema"))||!matchId.equals(json.getString("match_id")))throw new IllegalArgumentException("Schema/Spiel-ID stimmt nicht");
        JSONArray array=json.getJSONArray("events");if(array.length()>10000)throw new IllegalArgumentException("Zu viele Ereignisse");
        List<EventLedger.Event> events=new ArrayList<>();
        for(int i=0;i<array.length();i++){
            JSONObject e=array.getJSONObject(i);
            String occurred=e.getString("occurred_at");java.time.Instant.parse(occurred);
            events.add(new EventLedger.Event(matchId,e.getString("id"),e.getLong("revision"),e.getBoolean("deleted"),
                e.getString("type"),e.getString("label"),e.getString("side"),occurred,e.getLong("match_elapsed_ms"),e.getInt("period")));
        }
        return new Batch(events,json.getString("next_cursor"));
    }
}
