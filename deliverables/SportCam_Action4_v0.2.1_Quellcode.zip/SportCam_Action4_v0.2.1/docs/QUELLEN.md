# Quellen und Herkunft

Recherche am 4. November 2026. Implementierung eigenständig in Java anhand veröffentlichter Protokollbeschreibung. Es werden keine DJI-SDK-Binärdateien und kein fremder vollständiger Quellcode mitgeliefert. Der kleine Hex-Testvektor stammt aus dem offiziellen dokumentierten Mode-Switch-Beispiel.

## Primärquellen DJI

- DJI Osmo GPS Controller Demo, Protokollrahmen, CRC und Sequenzen:
  https://github.com/dji-sdk/Osmo-GPS-Controller-Demo/blob/main/docs/protocol.md
- Datenfelder, Kopplung 0019, Aufnahme 1D03, Status 1D02 und Abonnement 1D05:
  https://github.com/dji-sdk/Osmo-GPS-Controller-Demo/blob/main/docs/protocol_data_segment.md
- BLE-Grundlagen, FFF0/FFF4/FFF5, Identifizierung und Belegung des Kamerakanals:
  https://github.com/dji-sdk/Osmo-GPS-Controller-Demo/blob/main/docs/getting_started_guide.md
- CRC16-Initialwert und Referenzalgorithmus:
  https://github.com/dji-sdk/Osmo-GPS-Controller-Demo/blob/main/utils/crc/custom_crc16.h
  https://github.com/dji-sdk/Osmo-GPS-Controller-Demo/blob/main/utils/crc/custom_crc16.c
- CRC32-Initialwert und Referenzalgorithmus:
  https://github.com/dji-sdk/Osmo-GPS-Controller-Demo/blob/main/utils/crc/custom_crc32.h
  https://github.com/dji-sdk/Osmo-GPS-Controller-Demo/blob/main/utils/crc/custom_crc32.c

Die Dokumentation nennt Action 4 als unterstütztes Protokollgerät. Das ist keine Zertifizierung dieser SportCam-Implementierung. Insbesondere Identität, Firmware-Unterschiede, Timerwerte und Verbindungsmanagement bleiben zu testen. Die Kamera-ID wird aus der tatsächlichen Kopplungsanfrage gelesen, nicht wegen widersprüchlicher Byte-Darstellungen in Beispielen fest einprogrammiert.

## Android / Build

- Android Gradle Plugin 8.7: Gradle 8.9, JDK 17, maximal unterstützte API 35:
  https://developer.android.com/build/releases/past-releases/agp-8-7-0-release-notes
- Foreground-Service-Typ connectedDevice:
  https://developer.android.com/develop/background-work/services/fgs/service-types#connected-device
- Bluetooth-Laufzeitberechtigungen:
  https://developer.android.com/develop/connectivity/bluetooth/bt-permissions

## Nur als Recherche für eine spätere Vorschau

- Osmo Client (separates Projekt; kein hier eingebauter Android-Livebildcode):
  https://github.com/luisreysan/osmo-client

## Websiteprüfung

- Öffentlicher Supporter-Aufruf:
  https://www.tsvkirberg.de/index.php?option=com_bobradseason&view=supporter
- Versuchte Manifestprüfung:
  https://www.tsvkirberg.de/administrator/components/com_bobradseason/bobradseason.xml

Ergebnis in dieser Sitzung: Supporter-Seitentitel sichtbar, aber kein auswertbarer Komponentenquellcode/Manifestinhalt. Kein Zugriff auf geschützte Supporter-Funktionen, keine API bestätigt und kein vollständiger Versions-/Dateiabgleich möglich. Nichts auf dem Server verändert.

## Erweiterung 0.2 – WLAN-Livebild

Referenz: luisreysan/osmo-client, gelesener Tree-Commit `96cff353fb2ea582ed2e9835b183a82aeecf430b`, MIT-Lizenz. Die Protokollimplementierung wurde nach Java übertragen und auf die Action-4-Vorschau begrenzt. Der erfolgreiche Raspberry-Test des Referenzprojekts ist KEIN Test dieser Android-Portierung.

- https://github.com/luisreysan/osmo-client/blob/main/camlink/datalink.py
- https://github.com/luisreysan/osmo-client/blob/main/camlink/duml.py
- https://github.com/luisreysan/osmo-client/blob/main/camlink/protocol.py
- https://github.com/luisreysan/osmo-client/blob/main/LICENSE
- https://github.com/luisreysan/osmo-client/blob/main/NOTICE.md
- https://developer.android.com/develop/connectivity/wifi/wifi-bootstrap
- https://developer.android.com/develop/connectivity/wifi/wifi-permissions
- https://developer.android.com/reference/android/media/MediaCodec

Die ältere Überschrift „Nur als Recherche für eine spätere Vorschau“ beschreibt den Stand 0.1. In 0.2 ist Vorschaucode vorhanden, jedoch weiterhin nicht auf Android gebaut oder an Hardware geprüft.
